import React, { useCallback } from 'react';
import { useTranslation } from 'react-i18next';
import { InlineLoading } from '@carbon/react';
import { FormEngine } from '@openmrs/openmrs-form-engine-lib';
import { showModal, type Visit } from '@openmrs/esm-framework';
import { launchPatientWorkspace } from '@openmrs/esm-patient-common-lib';
import FormError from './form-error.component';
import useFormSchema from '../hooks/useFormSchema';
import styles from './form-renderer.scss';
import { type DefaultPatientWorkspaceProps } from '@openmrs/esm-patient-common-lib';

interface FormRendererProps extends DefaultPatientWorkspaceProps {
  additionalProps?: Record<string, any>;
  encounterUuid?: string;
  formUuid: string;
  patientUuid: string;
  visit?: Visit;
  closeDialogHandler?:(value:string)=>void;
}

const FormRenderer: React.FC<FormRendererProps> = ({
  additionalProps,
  closeWorkspace,
  closeWorkspaceWithSavedChanges,
  encounterUuid,
  formUuid,
  patientUuid,
  promptBeforeClosing,
  visit,
  closeDialogHandler
}) => {
  const { t } = useTranslation();
  const { schema, error, isLoading } = useFormSchema(formUuid);

  const handleCloseForm = useCallback((type) => {
    //closeWorkspace();
    closeDialogHandler(type)
    //!encounterUuid && launchPatientWorkspace('clinical-forms-workspace');
    //trigger any work space
  }, [closeDialogHandler]);


  const handleConfirmQuestionDeletion = useCallback(() => {
    return new Promise<void>((resolve, reject) => {
      const dispose = showModal('form-engine-delete-question-confirm-modal', {
        onCancel() {
          dispose();
          reject();
        },
        onConfirm() {
          dispose();
          resolve();
        },
      });
    });
  }, []);

  const handleMarkFormAsDirty = useCallback(
    (isDirty: boolean) => promptBeforeClosing(() => isDirty),
    [promptBeforeClosing],
  );

  if (isLoading) {
    return (
      <div className={styles.loaderContainer}>
        <InlineLoading className={styles.loading} description={`${t('loading', 'Loading')} ...`} />
      </div>
    );
  }

  if (error) {
    return (
      <div className={styles.errorContainer}>
        <FormError closeWorkspace={()=>handleCloseForm('close')} />
      </div>
    );
  }


  return (
    <>
      {schema && (
        <FormEngine
          encounterUUID={encounterUuid}
          formJson={schema}
          handleClose={()=>handleCloseForm("close")}
          handleConfirmQuestionDeletion={handleConfirmQuestionDeletion}
         // markFormAsDirty={handleMarkFormAsDirty}
          mode={additionalProps?.mode}
          onSubmit={()=>handleCloseForm("submit")}
          patientUUID={patientUuid}
          //visit={visit}
        />
      )}
    </>
  );
};

export default FormRenderer;
