import React, { useState, useRef, useEffect, useCallback } from 'react';
import { type To, useLocation, useNavigate } from 'react-router-dom';
import { type TFunction, useTranslation } from 'react-i18next';
import { Button, InlineLoading, InlineNotification, PasswordInput, TextInput, Tile } from '@carbon/react';
import mPowerLogo from '../assets/logonew.png'
import {
  ArrowLeftIcon,
  ArrowRightIcon,
  getCoreTranslation,
  interpolateUrl,
  navigate as openmrsNavigate,
  refetchCurrentUser,
  openmrsFetch,
  useConfig,
  useConnectivity,
  useSession,
  restBaseUrl,
} from '@openmrs/esm-framework';
import { type ConfigSchema } from '../config-schema';
import styles from './login.scss';

export interface LoginReferrer {
  referrer?: string;
}

const hidden: React.CSSProperties = {
  height: 0,
  width: 0,
  border: 0,
  padding: 0,
};

const Login: React.FC = () => {
  const { showPasswordOnSeparateScreen, provider: loginProvider, links: loginLinks, externalLogin } = useConfig<ConfigSchema>();
  const isLoginEnabled = useConnectivity();
  const { t } = useTranslation();
  const { user } = useSession();
  const location = useLocation() as unknown as Omit<Location, 'state'> & {
    state: LoginReferrer;
  };

  const rawNavigate = useNavigate();
  const navigate = useCallback(
    (to: To) => {
      rawNavigate(to, { state: location.state });
    },
    [rawNavigate, location.state],
  );

  const [errorMessage, setErrorMessage] = useState('');
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [password, setPassword] = useState('');
  const [username, setUsername] = useState('');
  const formRef = useRef<HTMLFormElement>(null);
  const passwordInputRef = useRef<HTMLInputElement>(null);
  const usernameInputRef = useRef<HTMLInputElement>(null);

  const showUsername = location.pathname === '/login';
  const showPassword = !showPasswordOnSeparateScreen || location.pathname === '/login/confirm';

  useEffect(() => {
    if (!user) {
      if (loginProvider.type === 'oauth2') {
        openmrsNavigate({ to: loginProvider.loginUrl });
      } else if (!username && location.pathname === '/login/confirm') {
        navigate('/login');
      }
    }
  }, [username, navigate, location, user, loginProvider]);

  useEffect(() => {
    const fieldToFocus =
      showPasswordOnSeparateScreen && showPassword ? passwordInputRef.current : usernameInputRef.current;

    fieldToFocus?.focus();
  }, [showPassword, showPasswordOnSeparateScreen]);

  const continueLogin = useCallback(() => {
    const usernameField = usernameInputRef.current;

    if (usernameField.value && usernameField.value.trim()) {
      navigate('/login/confirm');
    } else {
      usernameField.focus();
    }
  }, [location.state, navigate]);

  const changeUsername = useCallback((evt: React.ChangeEvent<HTMLInputElement>) => setUsername(evt.target.value), []);

  const changePassword = useCallback((evt: React.ChangeEvent<HTMLInputElement>) => setPassword(evt.target.value), []);

  const handleSubmit = useCallback(
    async (evt: React.FormEvent<HTMLFormElement>) => {
      evt.preventDefault();
      evt.stopPropagation();

      if (!showPassword) {
        continueLogin();
        return false;
      } else if (!password || !password.trim()) {
        passwordInputRef.current.focus();
        return false;
      }

      try {
        setIsLoggingIn(true);

        const sessionStore = await refetchCurrentUser(username, password);
        const session = sessionStore.session;
        const authenticated = sessionStore?.session?.authenticated;
        if (authenticated) {
          if (session.sessionLocation) {
            let to = loginLinks?.loginSuccess || '/home';
            if (location?.state?.referrer) {
              if (location.state.referrer.startsWith('/')) {
                to = `\${openmrsSpaBase}${location.state.referrer}`;
              } else {
                to = location.state.referrer;
              }
            }

            openmrsNavigate({ to });
          } else {
            navigate('/login/location');
          }
        } else {
          // Call external API call when login fails
          if (externalLogin?.enabled && externalLogin?.url) {
            try {
               console.log('Login failed, calling external API at:', externalLogin.url);

              // const externalLoginUrl = interpolateUrl(externalLogin.url);

              // const response = await openmrsFetch(`${restBaseUrl}/external/login`, {
              //   method:'POST',
              //   headers: {
              //     'Content-Type': 'application/json',
              //       'Authorization': 'Basic ' + btoa('admin:Admin123')
              //   },
              //   body: {
              //     username: username,
              //     password: password,
              //   }


              const externalLoginUrl = `${restBaseUrl}/external/login`;
              const externalLoginMethod = externalLogin?.method || 'POST';

              const response = await openmrsFetch(externalLoginUrl, {
                method: externalLoginMethod,
                headers: {
                  'Content-Type': 'application/json',
                  'Authorization': 'Basic ' + btoa('admin:Admin123')
                },
                body: JSON.stringify({ 
                  username: username,
                  password: password,
                })



              });
             
              if (response.ok) {

                  // External API call successful, now try to login again
                console.log('Response API call successful', response);
              
              

                try {

                
                 
                  const retrySessionStore = await refetchCurrentUser(username, password);
                  const retrySession = retrySessionStore.session;
                  const retryAuthenticated = retrySessionStore?.session?.authenticated;

                  if (retryAuthenticated) {
                    console.log('Auto-login successful after external API call');

                    // User is now authenticated, proceed with login flow
                    if (retrySession.sessionLocation) {
                      let to = loginLinks?.loginSuccess || '/home';
                      if (location?.state?.referrer) {
                        if (location.state.referrer.startsWith('/')) {
                          to = `\${openmrsSpaBase}${location.state.referrer}`;
                        } else {
                          to = location.state.referrer;
                        }
                      }

                      openmrsNavigate({ to });
                    } else {
                      navigate('/login/location');
                    }

                    // Clear form and return success
                    setUsername('');
                    setPassword('');
                    setErrorMessage('');
                    return true;
                  } else {
                    // Auto-login failed even after external API call
                  
                    setErrorMessage(t('loginStillFailed', 'Login failed even after creating account. Please try again.'));
                    setUsername('');
                    setPassword('');
                  }
                } catch (retryError) {
                  console.error('Error during auto-login retry:', retryError);
                  setErrorMessage(t('autoLoginError', 'Account created but auto-login failed. Please try logging in again.'));
                  setUsername('');
                  setPassword('');
                }
              } else {
                // External API call failed
                console.error('External API call failed:', response.status);
                setErrorMessage(t('externalLoginFailed', 'Failed to create account. Please try again.'));
                setUsername('');
                setPassword('');
              }
            } catch (externalError) {
              console.error('Error calling external API:', externalError);
              setErrorMessage(t('externalLoginError', 'Error connecting to external service. Please try again.'));
              setUsername('');
              setPassword('');
            }
          } else {
            // Fallback to original error behavior
            setErrorMessage(t('invalidCredentials', 'Invalid username or password'));
            setUsername('');
            setPassword('');

            if (showPasswordOnSeparateScreen) {
              navigate('/login');
            }
          }
        }

        return true;
      } catch (error: unknown) {
        if (error instanceof Error) {
          setErrorMessage(error.message);
        } else {
          setErrorMessage(t('invalidCredentials', 'Invalid username or password'));
        }

        setUsername('');
        setPassword('');

        if (showPasswordOnSeparateScreen) {
          navigate('/login');
        }
      } finally {
        setIsLoggingIn(false);
      }

      return false;
    },

    [showPassword, username, password, navigate, externalLogin, location, showPasswordOnSeparateScreen],
  );

  if (!loginProvider || loginProvider.type === 'basic') {
    return (
      <div className={styles.container}>
        <Tile className={styles.loginCard}>
          {errorMessage && (
            <div className={styles.errorMessage}>
              <InlineNotification
                kind="error"
                subtitle={t(errorMessage)}
                title={getCoreTranslation('error')}
                onClick={() => setErrorMessage('')}
              />
            </div>
          )}
          {showPasswordOnSeparateScreen && showPassword ? (
            <div className={styles.backButtonDiv}>
              <Button
                className={styles.backButton}
                iconDescription={t('backToUserNameIconLabel', 'Back to username')}
                kind="ghost"
                onClick={() => navigate('/login')}
                renderIcon={(props) => <ArrowLeftIcon {...props} size={24} />}
              >
                <span>{t('back', 'Back')}</span>
              </Button>
            </div>
          ) : null}
          <div className={styles.center}>
            <Logo t={t} />
          </div>
          <form onSubmit={handleSubmit} ref={formRef}>
            {showUsername && (
              <div className={styles.inputGroup}>
                <TextInput
                  id="username"
                  type="text"
                  name="username"
                  labelText={t('username', 'Username')}
                  value={username}
                  onChange={changeUsername}
                  ref={usernameInputRef}
                  autoFocus
                  required
                />
                {/* For password managers */}
                {showPasswordOnSeparateScreen && (
                  <input
                    id="password"
                    style={hidden}
                    type="password"
                    name="password"
                    value={password}
                    onChange={changePassword}
                  />
                )}
                {showPasswordOnSeparateScreen && (
                  <Button
                    className={styles.continueButton}
                    renderIcon={(props) => <ArrowRightIcon size={24} {...props} />}
                    type="submit"
                    iconDescription="Continue to login"
                    onClick={continueLogin}
                    disabled={!isLoginEnabled}
                  >
                    {t('continue', 'Continue')}
                  </Button>
                )}
              </div>
            )}
            {showPassword && (
              <div className={styles.inputGroup}>
                <PasswordInput
                  id="password"
                  invalidText={t('validValueRequired', 'A valid value is required')}
                  labelText={t('password', 'Password')}
                  name="password"
                  onChange={changePassword}
                  ref={passwordInputRef}
                  required
                  showPasswordLabel={t('showPassword', 'Show password')}
                  value={password}
                />
                {/* For password managers */}
                {showPasswordOnSeparateScreen && (
                  <input
                    id="username"
                    type="text"
                    name="username"
                    style={hidden}
                    value={username}
                    onChange={changeUsername}
                    required
                  />
                )}
                <Button
                  type="submit"
                  className={styles.continueButton}
                  renderIcon={(props) => <ArrowRightIcon size={24} {...props} />}
                  iconDescription="Log in"
                  disabled={!isLoginEnabled || isLoggingIn}
                >
                  {isLoggingIn ? (
                    <InlineLoading className={styles.loader} description={t('loggingIn', 'Logging in') + '...'} />
                  ) : (
                    <span>{t('login', 'Log in')}</span>
                  )}
                </Button>
              </div>
            )}
          </form>
        </Tile>
        <div className={styles.footer}>
          <p className={styles.poweredByTxt}>{t('poweredBy', 'Powered by')}</p>
          <div>
            <svg role="img" className={styles.poweredByLogo}>
              <use xlinkHref="#omrs-logo-partial-mono"></use>
            </svg>
          </div>
        </div>
      </div>
    );
  }

  return null;
};

const Logo: React.FC<{ t: TFunction }> = ({ t }) => {
  const { logo } = useConfig<ConfigSchema>();
  return logo.src ? (
    <img
      alt={logo.alt ? t(logo.alt) : t('openmrsLogo', 'OpenMRS logo')}
      className={styles.logoImg}
      src={interpolateUrl(logo.src)}
    />
  ) : (
    // <svg role="img" className={styles.logo}>
    //   <title>{t('openmrsLogo', 'OpenMRS logo')}</title>
    //   <use xlinkHref="#omrs-logo-full-color"></use>
    // </svg>
    <img
      alt={logo.alt ? t(logo.alt) : t('openmrsLogo', 'OpenMRS logo')}
      className={styles.logoImg}
      src={mPowerLogo}
    />
  );
};

export default Login;
