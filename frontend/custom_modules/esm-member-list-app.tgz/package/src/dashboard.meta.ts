export const dashboardMetaMemberList = {
  name: 'member-list',
  slot: 'member-list-dashboard-slot',
  title: 'Member List',
};

export const dashboardMetaReferredMemberList = {
  name: 'referred-member-search',
  slot: 'referred-member-search-dashboard-slot',
  title: 'Referred Member List',
};

export const dashboardMetaStockIn = {
  name: 'stock-in',
  title: 'Stock In',
};

export const dashboardMetaStockList = {
  name: 'stock-list',
  title: 'Stock List',
};
export const dashboardMetaStockDashboard = {
  name: 'stock-dashboard',
  title: 'Stock Dashboard',
};
