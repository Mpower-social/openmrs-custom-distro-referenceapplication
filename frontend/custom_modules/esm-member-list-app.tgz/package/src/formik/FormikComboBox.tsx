import { ComboBox } from '@carbon/react';
import { Field, useField } from 'formik';
import React, { useMemo, useState } from 'react';

interface SelectFieldProps {
  name: string;
  label?: string;
  className?: string;
  options: { value: string | number; label: string }[];
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  value?: string | number;
  id?: string;
  style?: React.CSSProperties;
  required?: boolean;
  disabled?: boolean;
  isRequired?: boolean;
}

const FormikComboBox: React.FC<SelectFieldProps> = ({ name, label = '', options = [], onChange, ...props }) => {
  const [, meta, helpers] = useField(name);
  const [inputValue, setInputValue] = useState('');

  // Format options for ComboBox
  const formattedOptions = useMemo(() => options.map((opt) => ({ id: String(opt.value), text: opt.label })), [options]);

  const handleChange = (selectedItem: { id: string } | null) => {
    const newValue = selectedItem?.id || '';
    helpers.setValue(newValue);
    if (onChange) {
      onChange({ target: { value: newValue } } as React.ChangeEvent<HTMLInputElement>);
    }
  };

  return (
    <div>
      <Field name={name}>
        {({ field }) => (
          <ComboBox
            id={name}
            items={formattedOptions}
            itemToString={(item) => (item ? item.text : '')}
            titleText={label}
            selectedItem={formattedOptions.find((item) => item.id === String(field.value)) || null}
            invalid={meta.touched && !!meta.error}
            invalidText={meta.error}
            onChange={({ selectedItem }) => handleChange(selectedItem)}
            onInputChange={(newInput) => setInputValue(newInput)}
            shouldFilterItem={({ item }) => item.text.toLowerCase().includes(inputValue.toLowerCase())}
            {...props}
          />
        )}
      </Field>
    </div>
  );
};

export default FormikComboBox;
