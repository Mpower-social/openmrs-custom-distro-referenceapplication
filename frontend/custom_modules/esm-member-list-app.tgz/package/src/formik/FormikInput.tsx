import { TextInput } from '@carbon/react';
import { useField } from 'formik';
import React from 'react';

interface InputFieldProps {
  name: string;
  label?: string;
  type?: string;
  className?: string;
  placeholder?: string;
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  value?: string | number;
  id?: string;
  style?: React.CSSProperties;
  required?: boolean;
  disabled?: boolean;
  isRequired?: boolean;
  min?:string;
  max?:string;
}

const FormikInput: React.FC<InputFieldProps> = ({ name, label,min,max, type = 'text', onChange, isRequired, ...props }) => {
  const [field, meta] = useField(name);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (onChange) {
      onChange(e);
    }
  };

  return (
    <div>
      <TextInput
        {...field}
        {...props}
        id={name}
        name={name}
        type={type}
        min={min}
        max={max}
        labelText={label || ''}
        invalid={meta.touched && !!meta.error}
        invalidText={meta.error}
        onChange={(e) => {
          field.onChange(e);
          handleChange(e);
        }}
      />
    </div>
  );
};

export default FormikInput;
