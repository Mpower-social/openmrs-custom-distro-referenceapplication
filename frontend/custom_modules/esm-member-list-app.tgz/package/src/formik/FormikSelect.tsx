import { Select } from '@carbon/react';
import { Field, useField } from 'formik';
import React from 'react';

interface SelectFieldProps {
  name: string;
  label?: string;
  className?: string;
  options: { value: string | number; label: string }[];
  onChange?: (e: React.ChangeEvent<HTMLSelectElement>) => void;
  value?: string | number;
  id?: string;
  style?: React.CSSProperties;
  required?: boolean;
  disabled?: boolean;
  isRequired?: boolean;
}

const FormikSelect: React.FC<SelectFieldProps> = ({ name, label, options, onChange, isRequired, ...props }) => {
  const [field, meta, helpers] = useField(name);

  const handleChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    if (onChange) {
      onChange(e);
    }
    helpers.setValue(e.target.value);
  };

  return (
    <div>
      <Field name={name}>
        {({ field }) => (
          <Select
            {...field}
            id={name}
            name={name}
            labelText={label || ''}
            value={field.value}
            onChange={handleChange}
            invalid={meta.touched && !!meta.error}
            invalidText={meta.error}
            {...props}
          >
            <option value="" disabled>
              Select an option
            </option>
            {options.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </Select>
        )}
      </Field>
    </div>
  );
};

export default FormikSelect;
