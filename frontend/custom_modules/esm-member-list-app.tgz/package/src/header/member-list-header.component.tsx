import React from 'react';
import { useTranslation } from 'react-i18next';
// import { useAppointmentServices } from '../hooks/useAppointmentService';
import SearchMemberIllustration from './search-member-illustration.component';
import VideoIllustration from './video-illustration.component';

import styles from './member-list-header.scss';
import StockIllustrationComponent from './stock-illustration.component';

interface AppointmentHeaderProps {
  title: string;
  secondTitle?: string;
  type?: 'video' | 'stock' | 'search';
}

const MemberListHeader: React.FC<AppointmentHeaderProps> = ({ title, secondTitle, type }) => {
  const { t } = useTranslation();

  const getIcon = (value: string | null) => {
    switch (value) {
      case 'video':
        return <VideoIllustration />;
      case 'stock':
        return <StockIllustrationComponent />;
      default:
        return <SearchMemberIllustration />;
    }
  };
  return (
    <div className={styles.header} data-testid="search-member-header">
      <div className={styles['left-justified-items']}>
        {getIcon(type)}
        <div className={styles['page-labels']}>
          <p>{t(secondTitle)}</p>
          <p className={styles['page-name']}>{t(title)}</p>
        </div>
      </div>
    </div>
  );
};

export default MemberListHeader;
