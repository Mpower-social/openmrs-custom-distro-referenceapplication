import React from 'react';

const StockIllustrationComponent = () => {
  return (
    <svg width={72} height={72} viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
      <title>Stock Management Illustration</title>
      <g fill="none" fillRule="evenodd">
        <rect width={200} height={200} fill="#FFF" />
        {/* Warehouse Structure */}
        <rect x={20} y={60} width={160} height={100} fill="#ffafa2" />
        <polygon points="20,60 100,20 180,60" fill="#ffafa2" />
        {/* Inventory Shelves */}
        <rect x={40} y={80} width={40} height={60} fill="#ed4246" />
        <rect x={120} y={80} width={40} height={60} fill="#ed4246" />
        {/* Boxes on Shelves */}
        <rect x={45} y={85} width={30} height={20} fill="#ed4246" />
        <rect x={125} y={85} width={30} height={20} fill="#ed4246" />
        <rect x={45} y={110} width={30} height={20} fill="#ed4246" />
        <rect x={125} y={110} width={30} height={20} fill="#ed4246" />
        {/* Bar Chart Representation */}
        <rect x={20} y={170} width={30} height={20} fill="#ed4246" />
        <rect x={60} y={160} width={30} height={30} fill="#ed4246" />
        <rect x={100} y={150} width={30} height={40} fill="#ed4246" />
        <rect x={140} y={140} width={30} height={50} fill="#ed4246" />
      </g>
    </svg>
  );
};

export default StockIllustrationComponent;
