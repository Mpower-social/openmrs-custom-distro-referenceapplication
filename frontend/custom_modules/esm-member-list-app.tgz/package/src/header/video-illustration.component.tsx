import React from 'react';

const VideoIllustration: React.FC = () => {
    return (
        <svg  width="82" height="84" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M13.75 18.75H5.25C3.8695 18.75 2.75 17.6305 2.75 16.25V7.75C2.75 6.3695 3.8695 5.25 5.25 5.25H13.75C15.1305 5.25 16.25 6.3695 16.25 7.75V16.25C16.25 17.6305 15.1305 18.75 13.75 18.75Z" stroke="#ED4246" stroke-width="2" stroke-miterlimit="10" />
            <path d="M16.25 14.25L21.25 17.25V6.75L16.25 9.75" stroke="#FFAFA2" stroke-width="2" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round" />
        </svg>

    );
};

export default VideoIllustration;
