import { useMemo } from 'react';

function useQueryParams<T extends Record<string, string>>() {
  const search = window.location.search;

  return useMemo(() => {
    const params = new URLSearchParams(search);
    const queryObject: Partial<T> = {};

    params.forEach((value, key) => {
      queryObject[key as keyof T] = value as T[keyof T];
    });

    return queryObject;
  }, [search]);
}

export default useQueryParams;
