import { defineConfigSchema, getAsyncLifecycle, getSyncLifecycle } from '@openmrs/esm-framework';
import { configSchema } from './config-schema';
import { createDashboardLink } from './createDashboardLink.component';
import {
  dashboardMetaMemberList,
  dashboardMetaReferredMemberList,
  dashboardMetaStockDashboard,
  dashboardMetaStockIn,
  dashboardMetaStockList,
} from './dashboard.meta';

const moduleName = '@openmrs/esm-member-list-app';

const createOptions = (featureName) => ({ featureName, moduleName });

const optionsMemberList = createOptions('member-list');
const optionsStockIn = createOptions('stock-in');
const optionsStockList = createOptions('stock-list');
const optionsStockDashboard = createOptions('stock-dashboard');
const optionsMemberReferredList = createOptions('referred-member-list');

export const importTranslation = require.context('../translations', false, /.json$/, 'lazy');

export function startupApp() {
  defineConfigSchema(moduleName, configSchema);
}

export const rootMemberList = getAsyncLifecycle(() => import('./root-member-list.component'), optionsMemberList);

export const rootStockIn = getAsyncLifecycle(
  () => import('./stocks-management/stock-in/root-stock-in.component'),
  optionsStockIn,
);
export const rootStockList = getAsyncLifecycle(
  () => import('./stocks-management/stock-list/root-stock-list.component'),
  optionsStockIn,
);
export const rootStockDashboard = getAsyncLifecycle(
  () => import('./stocks-management/stock-dashboard/root-stock-dashboard.component'),
  optionsStockIn,
);

export const rootReferredMemberList = getAsyncLifecycle(
  () => import('./root-referred-member-list.component'),
  optionsMemberReferredList,
);

export const listMemberDashboardLink = getSyncLifecycle(
  createDashboardLink(dashboardMetaMemberList),
  optionsMemberList,
);

export const listStockIn = getSyncLifecycle(createDashboardLink(dashboardMetaStockIn), optionsStockIn);
export const listStockList = getSyncLifecycle(createDashboardLink(dashboardMetaStockList), optionsStockList);
export const listStockDashboard = getSyncLifecycle(
  createDashboardLink(dashboardMetaStockDashboard),
  optionsStockDashboard,
);

export const listReferredMemberDashboardLink = getSyncLifecycle(
  createDashboardLink(dashboardMetaReferredMemberList),
  optionsMemberReferredList,
);
