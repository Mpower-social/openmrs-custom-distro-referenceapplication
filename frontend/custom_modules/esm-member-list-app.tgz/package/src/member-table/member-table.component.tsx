import { Layer, Pagination, SkeletonText } from '@carbon/react';
import { showSnackbar, useLayoutType } from '@openmrs/esm-framework';
import React, { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import SearchComponentForMember from '../other-components/search.component';
import TableComponentForMember from '../other-components/table-for-member.component';
import { findMembers } from '../resources/api.resource';
interface Member {
  uuid: string;
  person: {
    display: string;
    gender: string;
  };
  nid: string;
  phone: string;
  attributes: Array<{ attributeType: { display: string }; value: string }>;
}

const MemberListDataTable: React.FC = () => {
  const { t } = useTranslation();
  const isDesktopView = useLayoutType();
  const [members, setMembers] = useState<any>([]);
  const [filteredMembers, setFilteredMembers] = useState<any>([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [searchInput, setSearchInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [filters, setFilters] = useState<{ division?: string | number; district?: string | number; upazila?: string | number }>({});

  const searchMember = async () => {
    setLoading(true);
    try {
      const payload = {
        txt: searchInput,
        division: filters.division ? Number(filters.division) : 0,
        district: filters.district ? Number(filters.district) : 0,
        upazila: filters.upazila ? Number(filters.upazila) : 0,
      };
      const response = await findMembers(payload);
      setLoading(false);
      if (response.data.persons < 1) {
        showSnackbar({
          title: 'No Data Found',
          kind: 'error',
        });
        return;
      }
      setMembers(response.data.persons);
      setCurrentPage(1);
      setFilteredMembers(response.data.persons.slice(0, pageSize));
    } catch (error) {
      setLoading(false);
      console.error('Failed to fetch members:', error);
      showSnackbar({
        title: error.name,
        subtitle: error.message,
        kind: 'error',
      });
      setMembers([]);
    }
  };

  const numberLocalizationToBangla = (num: number) => {
    let temp = num.toString().split('');
    temp = temp.map((el) => t(el.toString(), el.toString()));
    return temp.join('');
  };

  useEffect(() => {
    setFilteredMembers([...members.slice((currentPage - 1) * pageSize, currentPage * pageSize)]);
  }, [pageSize, currentPage]);

  const memberChartUrl = '${openmrsSpaBase}/home/member-profile?id=';
  return (
    <>
      {
        <Layer style={{ margin: '0 10px' }}>
          <SearchComponentForMember
            onChange={(value) => setSearchInput(value)}
            onClick={() => searchMember()}
            onFilterChange={(f) => setFilters(f)}
          />
          {!loading ? (
            <>
              <TableComponentForMember members={filteredMembers} memberChartUrl={memberChartUrl} />
              <Pagination
                itemRangeText={(min, max, total) => `${t('totalItems', 'Total items')} ${t(total, total)}`}
                itemsPerPageText={t('itemsPerPage:', 'Items per page:')}
                pageRangeText={(_current, total) =>
                  eval(t('pageRangeText', "`of ${total} ${total === 1 ? 'page' : 'pages'}`"))
                }
                page={currentPage}
                pageSize={pageSize}
                pageSizes={[10, 20, 30, 40, 50].map((el) => el)}
                totalItems={members.length || '0'}
                onChange={({ page, pageSize }) => {
                  setCurrentPage(parseInt(page));
                  setPageSize(parseInt(pageSize));
                }}
              />
            </>
          ) : (
            <SkeletonText />
          )}
        </Layer>
      }
    </>
  );
};

export default MemberListDataTable;
