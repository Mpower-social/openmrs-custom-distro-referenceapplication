import React, { useEffect, useMemo, useState } from 'react';
import { Column, Select, SelectItem } from '@carbon/react';
import { useFetchLocations } from '../resources/location.resource';

export interface LocationFiltersProps {
  onChange?: (filters: { division?: string | number; district?: string | number; upazila?: string | number }) => void;
  rootDivisionId?: string | number;
}

const LocationFilters: React.FC<LocationFiltersProps> = ({ onChange, rootDivisionId = '24525' }) => {
  const [divisionId, setDivisionId] = useState<string>(''); // store IDs
  const [districtId, setDistrictId] = useState<string>('');
  const [upazilaId, setUpazilaId] = useState<string>('');

  const { fetchData: fetchDivision, data: divisions, isLoading: divisionLoading } = useFetchLocations();
  const {
    fetchData: fetchDistrict,
    data: districts,
    isLoading: districtLoading,
    resetState: resetDistrict,
  } = useFetchLocations();
  const {
    fetchData: fetchUpazila,
    data: upazilas,
    isLoading: upazilaLoading,
    resetState: resetUpazila,
  } = useFetchLocations();

  useEffect(() => {
    fetchDivision(rootDivisionId);
  }, [rootDivisionId]);


  useEffect(() => {
    if (divisionId) {
      fetchDistrict(divisionId);
    } else {
      resetDistrict();
    }
    setDistrictId('');
    setUpazilaId('');
  }, [divisionId]);


  useEffect(() => {
    if (districtId) {
      fetchUpazila(districtId);
    } else {
      resetUpazila();
    }
    setUpazilaId('');
  }, [districtId]);

  const emitChange = (next: { division?: string | number; district?: string | number; upazila?: string | number }) =>
    onChange?.(next);

  const divisionOptions = useMemo(() => divisions.main, [divisions.main]);
  const districtOptions = useMemo(() => districts.main, [districts.main]);
  const upazilaOptions = useMemo(() => upazilas.main, [upazilas.main]);

  return (
    <>
      <Column sm={4} md={4} lg={2} style={{ paddingLeft: 0 }}>
        <Select
          id="filter-division"
          labelText="Division Test"
          onChange={(e) => {
            const value = (e.target as HTMLSelectElement).value;
            setDivisionId(value);
            emitChange({ division: value || undefined });
          }}
          value={divisionId}
          disabled={divisionLoading}
        >
          <SelectItem value="" text="Select an option" />
          {divisionOptions.map((d) => (
            <SelectItem key={String(d.location_id)} value={String(d.location_id)} text={d.description} />
          ))}
        </Select>
      </Column>
      <Column sm={4} md={4} lg={2} style={{ paddingLeft: 0 }}>
        <Select
          id="filter-district"
          labelText="District"
          onChange={(e) => {
            const value = (e.target as HTMLSelectElement).value;
            setDistrictId(value);
            emitChange({ division: divisionId || undefined, district: value || undefined });
          }}
          value={districtId}
          disabled={!divisionId || districtLoading}
        >
          <SelectItem value="" text="Select an option" />
          {districtOptions.map((d) => (
            <SelectItem key={String(d.location_id)} value={String(d.location_id)} text={d.description} />
          ))}
        </Select>
      </Column>
      <Column sm={4} md={4} lg={2} style={{ paddingLeft: 0 }}>
        <Select
          id="filter-upazila"
          labelText="Upazila"
          onChange={(e) => {
            const value = (e.target as HTMLSelectElement).value;
            setUpazilaId(value);
            emitChange({ division: divisionId || undefined, district: districtId || undefined, upazila: value || undefined });
          }}
          value={upazilaId}
          disabled={!districtId || upazilaLoading}
        >
          <SelectItem value="" text="Select an option" />
          {upazilaOptions.map((u) => (
            <SelectItem key={String(u.location_id)} value={String(u.location_id)} text={u.description} />
          ))}
        </Select>
      </Column>
    </>
  );
};

export default LocationFilters;
