import React from 'react';
import { Grid, Column, Search, Button } from '@carbon/react';
import { useTranslation } from 'react-i18next';
import LocationFilters from './location-filters.component';

interface SearchComponentForMemberProps {
  onChange?: (evt) => void;
  onClick?: () => void;
  memberChartUrl?: string;
  onFilterChange?: (filters: { division?: string; district?: string; upazila?: string }) => void;
}

const SearchComponentForMember: React.FC<SearchComponentForMemberProps> = ({ onChange, onClick, onFilterChange }) => {
  const { t } = useTranslation();

  return (
    <Grid data-test-id="search-member-header" style={{
      padding: '20px',
      display: 'flex',
      alignItems: 'flex-start',
      gap: '16px'
    }}>
      <Column sm={4} md={4} lg={4} style={{
        paddingLeft: '0',
        marginTop: '24px'
      }}>
        <Search
          labelText={t('search', 'Search')}
          onKeyDown={(e) => e.key == 'Enter' && onClick()}
          onChange={(e) => onChange(e.target.value)}
          placeholder={t('sarchByName/NID/BRID', 'Search by Name/NID/BRID')}
        />
      </Column>

      {/* Division / District / Upazila filters */}
      <LocationFilters onChange={onFilterChange} />

      <Column sm={4} md={4} lg={2} style={{
        paddingLeft: '0',
        display: 'flex',
        alignItems: 'center',
        marginTop: '24px'
      }}>
        <Button size="md" onClick={() => onClick()}>
          {t('search', 'Search')}
        </Button>
      </Column>
    </Grid>
  );
};

export default SearchComponentForMember;
