import { Table, TableBody, TableCell, TableContainer, TableHead, TableRow } from '@carbon/react';
import { WarningAlt } from '@carbon/react/icons';
import { ConfigurableLink } from '@openmrs/esm-framework';
import React from 'react';
import { useTranslation } from 'react-i18next';

interface Member {
  uuid: string;
  person: {
    display: string;
    gender: string;
  };
  nid: string;
  phone: string;
  attributes: Array<{ attributeType: { display: string }; value: string }>;
}
interface TableComponentForMemberProps {
  onChange?: (evt) => void;
  members?: Array<any>;
  memberChartUrl?: string;
}

const valueFromAttribute = (attributes: Array<{ attributeType: { display: string }; value: string }>, key: string) => {
  const attribute = attributes.find((attr) => attr.attributeType.display === key);
  return attribute?.value || 'N/A';
};

function formatDateFromTimestamp(timestamp: number): string {
  // Create a new Date object using the given timestamp
  const date: Date = new Date(timestamp);

  // Extract the date components
  const year: number = date.getUTCFullYear();
  const month: string = ('0' + (date.getUTCMonth() + 1)).slice(-2); // Months are zero-based
  const day: string = ('0' + date.getUTCDate()).slice(-2);
  const hours: string = ('0' + date.getUTCHours()).slice(-2);
  const minutes: string = ('0' + date.getUTCMinutes()).slice(-2);
  const seconds: string = ('0' + date.getUTCSeconds()).slice(-2);

  // Format the date string
  const formattedDate: string = `${year}-${month}-${day}`;

  return formattedDate;
}

const TableComponentForMember: React.FC<TableComponentForMemberProps> = ({ members, memberChartUrl }) => {
  const { t } = useTranslation();

  return (
    <div data-testid="list-member-header">
      <TableContainer data-testid="encountersTable">
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>{t('id', 'ID')}</TableCell>
              <TableCell>{t('memberName', 'Member name')}</TableCell>
              <TableCell>{t('memberId', 'Member Id')}</TableCell>
              <TableCell>{t('motherName', 'Mother name')}</TableCell>
              <TableCell>{t('mobileNumber', 'Mobile number')}</TableCell>
              <TableCell>{t('dob', 'DOB')}</TableCell>
              <TableCell>{t('gender', 'Gender')}</TableCell>
              <TableCell>{t('ward', 'Ward')}</TableCell>
              <TableCell>{t('block', 'Block')}</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {members.map((member, index) => (
              <TableRow key={member.uuid}>
                <TableCell>{member.id}</TableCell>
                <TableCell>
                  <ConfigurableLink
                    to={memberChartUrl + member.personUuid}
                    templateParams={{ patientUuid: member.uuid }}
                  >
                    <span style={{ display: 'flex', alignItems: 'center' }}>
                      {member.highRisk && (
                        <WarningAlt
                          color="red"
                          style={{ fontSize: '30px', width: '30px', height: '20px', marginRight: '8px' }}
                        />
                      )}
                      <span>{member.firstName + ' ' + member.lastName}</span>
                    </span>
                  </ConfigurableLink>
                </TableCell>

                <TableCell>{member.person}</TableCell>
                <TableCell>{member.motherName}</TableCell>
                <TableCell>{member.mobile}</TableCell>
                <TableCell>{formatDateFromTimestamp(member.birthdate)}</TableCell>
                <TableCell>{member.gender}</TableCell>
                <TableCell>{member.ward}</TableCell>
                <TableCell>{member.block}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </div>
  );
};

export default TableComponentForMember;
