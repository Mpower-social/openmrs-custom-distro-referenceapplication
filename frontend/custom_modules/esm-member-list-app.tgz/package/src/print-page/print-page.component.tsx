import React, { useEffect, useState, useMemo, useRef } from 'react';
import classNames from 'classnames';
import { useTranslation } from 'react-i18next';
import { Printer } from '@carbon/icons-react';

import {
  Layer,
  Tile,
  TextInput,
  Grid,
  Column,
  Button,
  InlineLoading,
  Pagination,
  Search,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableHeader,
  TableRow,
} from '@carbon/react';
import {
  useLayoutType,
  isDesktop,
  useConfig,
  usePagination,
  ExtensionSlot,
  ErrorState,
  ConfigurableLink,
} from '@openmrs/esm-framework';
import styles from './member-table.scss';

interface PrintProps {}

const PrintPage: React.FC<PrintProps> = ({}) => {
  const { t } = useTranslation();
  const layout = useLayoutType();
  const [members, setMember] = useState([]);

  useEffect(() => {
    console.log(members, 'members');
  }, [members]);

  const printHandler = () => {
    window.print();
  };

  const memberChartUrl = '${openmrsSpaBase}/member/${memberUuid}/edit';

  return (
    <div style={{ margin: '0 20px' }}>
      <h1>Hello ..............</h1>
    </div>
  );
};

export default PrintPage;
