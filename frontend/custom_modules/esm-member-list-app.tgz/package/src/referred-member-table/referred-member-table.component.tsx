import React, { useEffect, useState } from 'react';
import classNames from 'classnames';
import { useTranslation } from 'react-i18next';
import { Layer, Pagination } from '@carbon/react';
import { useLayoutType } from '@openmrs/esm-framework';
import styles from './referred-member-table.scss';
import { findReferredMembers } from '../resources/api.resource';
import TableComponentForMember from '../other-components/table-for-member.component';
import SearchComponentForMember from '../other-components/search.component';

const MemberReferredListDataTable: React.FC = () => {
  const { t } = useTranslation();
  const isDesktopView = useLayoutType();
  const [referredMembers, setReferredMembers] = useState<any>([]);
  const [filteredMembers, setFilteredMembers] = useState<any>([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [searchInput, setSearchInput] = useState('');

  const searchMember = async () => {
    try {
      const response = await findReferredMembers({ txt: searchInput });
      if (response.data.persons < 1) return;
      setReferredMembers(response.data.persons);
      setCurrentPage(1);
      //setPageSize(10);
      setFilteredMembers(response.data.persons.slice(0, pageSize));
    } catch (error) {
      console.error('Failed to fetch members:', error);
      setReferredMembers([]);
    }
  };

  useEffect(() => {
    setFilteredMembers(referredMembers.slice((currentPage - 1) * pageSize, currentPage * pageSize));
  }, [pageSize, currentPage]);

  useEffect(() => {
    searchMember()
  }, []);

  const referredMemberChartUrl = '${openmrsSpaBase}/home/member-profile?id=';
  return (
    <>
      {
        <Layer style={{ margin: '0 10px' }}>
          <div
            className={classNames({ [styles.tabletHeading]: !isDesktopView, [styles.desktopHeading]: isDesktopView })}
          ></div>
          <SearchComponentForMember onChange={(value) => setSearchInput(value)} onClick={searchMember} />

          <TableComponentForMember members={filteredMembers} memberChartUrl={referredMemberChartUrl} />
          <Pagination
            itemRangeText={(min, max, total) => `${t('totalItems', 'Total items')} ${t(total, total)}`}
            itemsPerPageText={t('itemsPerPage:', 'Items per page:')}
            pageRangeText={(_current, total) =>
              eval(t('pageRangeText', "`of ${total} ${total === 1 ? 'page' : 'pages'}`"))
            }
            page={currentPage}
            pageSize={pageSize}
            pageSizes={[10, 20, 30, 40, 50].map((el) => el)}
            totalItems={referredMembers.length || '0'}
            onChange={({ page, pageSize }) => {
              setCurrentPage(parseInt(page));
              setPageSize(parseInt(pageSize));
            }}
          />
        </Layer>
      }
    </>
  );
};

export default MemberReferredListDataTable;
