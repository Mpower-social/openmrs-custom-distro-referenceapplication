import { openmrsFetch, restBaseUrl } from '@openmrs/esm-framework';

export function findMembers(body: any) {
  const url = `${restBaseUrl}/custom-person/search`;
  const abortController = new AbortController();
  return openmrsFetch(url, {
    method: 'POST',
    signal: abortController.signal,
    body: body,
    headers: {
      'Content-Type': 'application/json',
    },
  });
}

export function findReferredMembers(body?: any) {
  const url = `${restBaseUrl}/custom-person/refered`;
  const abortController = new AbortController();

  return openmrsFetch(url, {
    method: 'POST',
    signal: abortController.signal,
    body: body,
    headers: {
      'Content-Type': 'application/json',
    },
  });
}

export const stockManagement = {
  stockProductList: () => {
    const url = `${restBaseUrl}/stock/all-product`;
    return openmrsFetch(url, {
      method: 'GET',
      signal: new AbortController().signal,
      headers: {
        'Content-Type': 'application/json',
      },
    });
  },

  stockProductItemCount: (id) => {
    const url = `${restBaseUrl}/stock/getCurrentStockByItem/${id}`;
    return openmrsFetch(url, {
      method: 'GET',
      signal: new AbortController().signal,
      headers: {
        'Content-Type': 'application/json',
      },
    });
  },
  patientGivenMedicineList: (id) => {
    const url = `${restBaseUrl}/product-distribute/patient/${id}`;
    return openmrsFetch(url, {
      method: 'GET',
      signal: new AbortController().signal,
      headers: {
        'Content-Type': 'application/json',
      },
    });
  },
  saveProductDistribution: (payload) => {
    const url = `${restBaseUrl}/product-distribute/save-update`;
    return openmrsFetch(url, {
      method: 'POST',
      signal: new AbortController().signal,
      body: JSON.stringify(payload),
      headers: {
        'Content-Type': 'application/json',
      },
    });
  },
  saveStockIn: (payload) => {
    const url = `${restBaseUrl}/stock/save`;
    return openmrsFetch(url, {
      method: 'POST',
      signal: new AbortController().signal,
      body: JSON.stringify(payload),
      headers: {
        'Content-Type': 'application/json',
      },
    });
  },
  stockList: (payload) => {
    const url = `${restBaseUrl}/stock/list`;
    return openmrsFetch(url, {
      method: 'POST',
      signal: new AbortController().signal,
      body: JSON.stringify(payload),
      headers: {
        'Content-Type': 'application/json',
      },
    });
  },
  stockDashboard: (payload) => {
    const url = `${restBaseUrl}/stock/dashboard`;
    return openmrsFetch(url, {
      method: 'POST',
      signal: new AbortController().signal,
      body: JSON.stringify(payload),
      headers: {
        'Content-Type': 'application/json',
      },
    });
  },
  stockAdjust: (payload) => {
    const url = `${restBaseUrl}/stock/save-adjust`;
    return openmrsFetch(url, {
      method: 'POST',
      signal: new AbortController().signal,
      body: JSON.stringify(payload),
      headers: {
        'Content-Type': 'application/json',
      },
    });
  },
};
