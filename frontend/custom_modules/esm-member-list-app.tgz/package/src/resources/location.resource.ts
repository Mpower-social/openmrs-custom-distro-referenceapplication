import { openmrsFetch, restBaseUrl, showSnackbar } from '@openmrs/esm-framework';
import { useState } from 'react';

type Location = {
  location_id: number;
  description: string;
  parent_location: number;
  location_tag_id: number;
};

interface FetchState {
  isLoading: boolean;
  data: {
    main: Location[];
    processed: { uuid: string; label: string }[];
  };
}

export function useFetchLocations() {
  const [res, setRes] = useState<FetchState>({
    data: { main: [], processed: [] },
    isLoading: true,
  });

  const fetchData = async (locationId: string | number): Promise<void> => {
    const url = `${restBaseUrl}/custom-location/childLocation?parentLocationIds=${locationId}`;
    const abortController = new AbortController();

    setRes((prev) => ({ ...prev, isLoading: true }));

    try {
      const response = await openmrsFetch(url, {
        signal: abortController.signal,
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = response.data;

      setRes((prev) => ({
        ...prev,
        data: {
          main: data?.locations ?? [],
          processed:
            data?.locations?.map((item: any) => ({
              uuid: item.description,
              label: item.description,
            })) ?? [],
        },
      }));
    } catch (error: any) {
      if (error.name === 'AbortError') {
        // no-op
      } else {
        showSnackbar({ title: error.name, subtitle: error.message, kind: 'error' });
      }
    } finally {
      setRes((prev) => ({ ...prev, isLoading: false }));
    }
  };

  const resetState = () =>
    setRes(() => ({
      data: { main: [], processed: [] },
      isLoading: true,
    }));

  return { fetchData, resetState, ...res };
}

export const getLocationId = (arr: any[], locationName: string) =>
  arr?.find((item: any) => item?.description === locationName)?.location_id;
