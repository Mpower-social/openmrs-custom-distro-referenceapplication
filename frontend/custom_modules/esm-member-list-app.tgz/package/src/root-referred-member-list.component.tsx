/**
 * From here, the application is pretty typical React, but with lots of
 * support from `@openmrs/esm-framework`. Check out `Greeter` to see
 * usage of the configuration system, and check out `MemberGetter` to
 * see data fetching using the OpenMRS FHIR API.
 *
 * Check out the Config docs:
 *   https://openmrs.github.io/openmrs-esm-core/#/main/config
 */
import React from 'react';
import { useTranslation } from 'react-i18next';
import { useSession } from '@openmrs/esm-framework'; // Add this import
import MemberListHeader from './header/member-list-header.component';
import MemberReferredListDataTable from './referred-member-table/referred-member-table.component';

// Helper function to extract community clinic name from display
const extractCommunityName = (display: string): string => {
  if (!display) return 'Loading...';

  // Check if it's in the format: "Name - Community Clinic , Location"
  if (display.includes('-') && display.includes(',')) {
    const parts = display.split('-');
    if (parts.length >= 2) {
      // Get the part after the hyphen and before the comma
      const clinicPart = parts[1].split(',')[0].trim();
      return clinicPart;
    }
  }

  // For Super Admin or other formats, return as is
  return display;
};

const Root: React.FC = () => {
  const { t } = useTranslation();
  const session = useSession();

  // Extract community name from session
  const communityName = extractCommunityName(session?.user?.person?.display);

  return (
    <>
      <MemberListHeader
        title={t('referredMemberList', 'Referred Member List')}
        key="referredMemberList"
        communityName={communityName}
      />
      <br />
      <MemberReferredListDataTable />
    </>
  );
};

export default Root;
