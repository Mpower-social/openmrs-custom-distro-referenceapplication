import {
  Button,
  Column,
  Grid,
  Layer,
  Loading,
  Pagination,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
} from '@carbon/react';
import { Form, Formik } from 'formik';
import React, { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import * as Yup from 'yup';
import FormikInput from '../../formik/FormikInput';
import FormikSelect from '../../formik/FormikSelect';
import MemberListHeader from '../../header/member-list-header.component';
import { useFetchData } from '../../hooks/useFetchData';
import { usePostData } from '../../hooks/usePostData';
import { stockManagement } from '../../resources/api.resource';
import styles from './stockDashboard-styles.scss';

const StockDashboard = () => {
  const { t } = useTranslation();
  const { data: stockProductListData, loading: stockProductListLoading } = useFetchData(
    stockManagement.stockProductList,
  );
  const { postData, loading, data } = usePostData({ fn: stockManagement.stockDashboard });

  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [paginatedData, setPaginatedData] = useState([]);

  useEffect(() => {
    postData({ startDate: '', endDate: '', invoice: '', drugId: 0 });
  }, []);

  useEffect(() => {
    if (data) {
      setPaginatedData(data.slice((currentPage - 1) * pageSize, currentPage * pageSize));
    }
  }, [data, currentPage, pageSize]);

  const validationSchema = Yup.object().shape({
    startDate: Yup.string().optional(),
    endDate: Yup.string().optional(),
    drugId: Yup.string().optional(),
  });

  if (loading || stockProductListLoading) return <Loading active={loading} />;

  return (
    <div>
      <MemberListHeader
        title={t('stock_list', 'Stock Dashboard')}
        secondTitle={t('stock_management', 'Stock Management')}
        type="stock"
      />
      <Layer className={styles['stock-in-form']}>
        <Formik
          initialValues={{ startDate: '', endDate: '', drugId: '', invoice: '' }}
          validationSchema={validationSchema}
          onSubmit={(values) => postData({ ...values, drugId: values.drugId || 0 })}
          enableReinitialize
        >
          {() => (
            <Form>
              <fieldset disabled={loading}>
                <Grid fullWidth className="grid-gap">
                  <Column sm={4} md={2} lg={4}>
                    <FormikInput
                      id="startDate"
                      name="startDate"
                      type="date"
                      label={t('from_stock_in_date', 'FROM: Stock In Date')}
                    />
                  </Column>
                  <Column sm={4} md={2} lg={4}>
                    <FormikInput
                      id="endDate"
                      name="endDate"
                      type="date"
                      label={t('to_stock_in_date', 'TO: Stock In Date')}
                    />
                  </Column>
                  <Column sm={4} md={2} lg={4}>
                    <FormikSelect
                      options={
                        (stockProductListData as any)
                          ?.sort((a, b) => a.name.localeCompare(b.name))
                          .map((item) => ({ value: item.id, label: item.name })) || []
                      }
                      id="drugId"
                      name="drugId"
                      label={t('drug_id', 'Drug')}
                    />
                  </Column>
                </Grid>
                <div className={styles['action-buttons']}>
                  <Button size="lg" type="submit">
                    {t('submit', 'Submit')}
                  </Button>
                </div>
              </fieldset>
            </Form>
          )}
        </Formik>
        <div className={styles['table-container']}>
          <TableContainer>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>#</TableCell>
                  <TableCell>{t('item', 'Item')}</TableCell>
                  <TableCell>{t('currentStock', 'Current Stock')}</TableCell>
                  <TableCell>{t('stockIn', 'Stock In')}</TableCell>
                  <TableCell>{t('stockOut', 'Stock Out')}</TableCell>
                  <TableCell>{t('stockDiff', 'Stock Diff')}</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {paginatedData?.map((item, index) => (
                  <TableRow key={index}>
                    <TableCell>{(currentPage - 1) * pageSize + index + 1}</TableCell>
                    <TableCell>{item.name}</TableCell>
                    <TableCell>{item.currentstock}</TableCell>
                    <TableCell>{item.stockin}</TableCell>
                    <TableCell>{item.stockout}</TableCell>
                    <TableCell>{item.adjust_amount}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
          <Pagination
            itemRangeText={(min, max, total) => `${t('totalItems', 'Total items')} ${t(total, total)}`}
            itemsPerPageText={t('itemsPerPage:', 'Items per page:')}
            pageRangeText={(_current, total) => `${t('pageRangeText', `of ${total} pages`)}`}
            page={currentPage}
            pageSize={pageSize}
            pageSizes={[10, 20, 30, 40, 50]}
            totalItems={data?.length || 0}
            onChange={({ page, pageSize }) => {
              setCurrentPage(page);
              setPageSize(pageSize);
            }}
          />
        </div>
      </Layer>
    </div>
  );
};

export default StockDashboard;
