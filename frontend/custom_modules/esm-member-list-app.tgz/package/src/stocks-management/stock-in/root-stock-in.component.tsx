import {
  Button,
  Layer,
  Loading,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
} from '@carbon/react';
import { showSnackbar } from '@openmrs/esm-framework';
import { FieldArray, Form, Formik, useFormikContext } from 'formik';
import React, { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import * as Yup from 'yup';
import FormikInput from '../../formik/FormikInput';
import FormikSelect from '../../formik/FormikSelect';
import MemberListHeader from '../../header/member-list-header.component';
import { useFetchData } from '../../hooks/useFetchData';
import { usePostData } from '../../hooks/usePostData';
import { stockManagement } from '../../resources/api.resource';
import styles from './stockin-styles.scss'; // Assuming the CSS file is named stockin-styles.module.css
function getFormattedDateTime() {
  const now = new Date();
  now.setMinutes(now.getMinutes() - now.getTimezoneOffset()); // Adjust for timezone offset

  return now.toISOString().slice(0, 16);
}
const StockIn = () => {
  const { t } = useTranslation();
  const { data, loading } = useFetchData<any[]>(stockManagement.stockProductList);
  const { postData, loading: loadingSubmission } = usePostData({
    fn: stockManagement.saveStockIn,
  });
  // Formik validation schema for form data

  const validationSchema = Yup.object().shape({
    stockInDate: Yup.string().required('Stock date is required'),
    invoice: Yup.string().required('Stock date is required'),
    stocks: Yup.array().of(
      Yup.object().shape({
        drugId: Yup.string().required('Item is required'),
        currentStock: Yup.number().typeError('Stock must be a number').required('Stock is required'),
        quantity: Yup.number().typeError('Quantity must be a number').required('Quantity is required'),
        expire: Yup.string().required('Expired date is required'),
        batchNo: Yup.string().optional(),
        receivedFrom: Yup.string().optional(),
      }),
    ),
  });
  if (loading) return <Loading active={loading} />;
  return (
    <div>
      <MemberListHeader title="Stock In" secondTitle="Stock Management" type="stock" />
      <Layer className={styles['stock-in-form']}>
        <Formik
          initialValues={{
            stockInDate: getFormattedDateTime(),
            invoice: '',
            stocks: [{ drugId: '', quantity: '', currentStock: '', expire: '', batchNo: '', receivedFrom: '' }],
          }}
          validationSchema={validationSchema}
          onSubmit={async (values, { resetForm }) => {
            const payload = values.stocks.map((item) => ({
              ...item,
              stockInDate: values.stockInDate,
              invoice: values.invoice,
            }));
            postData(payload, () => {
              resetForm();
              showSnackbar({
                title: 'Stock added Successfully',
                kind: 'success',
              });
            });
          }}
        >
          {({ values }) => (
            <Form>
              {' '}
              <fieldset disabled={loadingSubmission}>
                <div className={styles['form-fields-container']}>
                  {' '}
                  {/* This container holds the form fields */}
                  <div className={styles['form-field']}>
                    <FormikInput
                      id="stockInDate"
                      name="stockInDate"
                      placeholder="YYYY-MM-DD"
                      type="datetime-local"
                      label="Stock In Date"
                      isRequired
                    />
                  </div>
                  <div className={styles['form-field']}>
                    <FormikInput label="Invoice" id="invoice" name="invoice" placeholder="Invoice Number" isRequired />
                  </div>
                </div>

                <FieldArray name="stocks">
                  {({ remove, push }) => (
                    <div className={styles['stock-table-container']}>
                      <TableContainer>
                        <Table>
                          <TableHead>
                            <TableRow>
                              <TableCell>SN</TableCell>
                              <TableCell>
                                Item <small style={{ color: 'red' }}>*</small>
                              </TableCell>
                              <TableCell>{t('currentStock', 'Current Stock')}</TableCell>
                              <TableCell>
                                Quantity <small style={{ color: 'red' }}>*</small>
                              </TableCell>
                              <TableCell>
                                Expiry Date <small style={{ color: 'red' }}>*</small>
                              </TableCell>
                              <TableCell>Batch No</TableCell>
                              <TableCell>Received From</TableCell>
                              <TableCell>Actions</TableCell>
                            </TableRow>
                          </TableHead>
                          <TableBody>
                            {values.stocks.map((_, index, mainArray) => (
                              <TableRow key={index}>
                                <TableCell>{index + 1}</TableCell>

                                <TableCell style={{ maxWidth: '200px' }}>
                                  <StockProductList index={index} data={data} />
                                </TableCell>
                                <TableCell>
                                  <FormikInput
                                    name={`stocks.${index}.currentStock`}
                                    placeholder="Current Stock"
                                    disabled
                                  />
                                </TableCell>
                                <TableCell>
                                  <FormikInput name={`stocks.${index}.quantity`} placeholder="Quantity" isRequired />
                                </TableCell>
                                <TableCell>
                                  <FormikInput
                                    name={`stocks.${index}.expire`}
                                    placeholder="Expiry Date"
                                    type="date"
                                    isRequired
                                  />
                                </TableCell>
                                <TableCell>
                                  <FormikInput name={`stocks.${index}.batchNo`} placeholder="Batch No" />
                                </TableCell>
                                <TableCell>
                                  <FormikSelect
                                    name={`stocks.${index}.receivedFrom`}
                                    options={['CBHC HQ', 'Local Procurement', 'NGO', 'Other'].map((i) => ({
                                      value: i,
                                      label: i,
                                    }))}
                                  />
                                </TableCell>
                                <TableCell>
                                  <div style={{ display: 'flex', justifyContent: 'center', gap: 4 }}>
                                    <button
                                      type="button"
                                      title="Delete"
                                      className={styles['delete-button']}
                                      onClick={() => remove(index)}
                                      disabled={mainArray.length === 1}
                                    >
                                      <svg
                                        xmlns="http://www.w3.org/2000/svg"
                                        viewBox="0 0 24 24"
                                        width="24"
                                        height="24"
                                      >
                                        <path
                                          fill="none"
                                          stroke="#D32F2F"
                                          strokeWidth="2"
                                          d="M3 6h18M5 6l1 14h12l1-14M10 6V4a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v2M4 6h16"
                                        />
                                      </svg>
                                    </button>{' '}
                                    <button
                                      style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}
                                      type="button"
                                      onClick={() =>
                                        push({
                                          drugId: '',
                                          quantity: '',
                                          currentStock: '',
                                          expire: '',
                                          batchNo: '',
                                          receivedFrom: '',
                                        })
                                      }
                                      className={styles['delete-button']}
                                    >
                                      <div
                                        style={{
                                          width: '25px',
                                          height: '25px',
                                          display: 'flex',
                                          justifyContent: 'center',
                                          alignItems: 'center',
                                        }}
                                      >
                                        <svg
                                          xmlns="http://www.w3.org/2000/svg"
                                          width={15}
                                          height={15}
                                          viewBox="0 0 100 100"
                                        >
                                          <rect x={40} y={10} width={20} height={80} fill="black" />
                                          <rect x={10} y={40} width={80} height={20} fill="black" />
                                        </svg>
                                      </div>
                                    </button>
                                  </div>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </TableContainer>
                    </div>
                  )}
                </FieldArray>

                <div className={styles['action-buttons']}>
                  <Button size="sm" type="submit">
                    {t('submit', 'Submit')}
                  </Button>
                </div>
              </fieldset>
            </Form>
          )}
        </Formik>
      </Layer>
    </div>
  );
};

export default StockIn;

interface StockProductListProps {
  index: number;
  data: any[];
}

const StockProductList: React.FC<StockProductListProps> = ({ index, data }) => {
  const { setFieldValue } = useFormikContext();
  const [stockCount, setStockCount] = useState<number | null>(null);

  // Fetch stock count for the selected drug
  const { postData, loading } = usePostData({
    fn: stockManagement.stockProductItemCount,
    onSuccess: (result) => {
      setStockCount(result.count || 0);
      setFieldValue(`stocks.${index}.currentStock`, result.count || 0);
    },
    onError: () => {
      setFieldValue(`stocks.${index}.currentStock`, 0);
    },
  });

  useEffect(() => {
    if (stockCount !== null) {
      setFieldValue(`stocks.${index}.currentStock`, stockCount);
    }
  }, [stockCount, setFieldValue, index]);

  return (
    <>
      {loading && <Loading active={loading} />}
      <FormikSelect
        isRequired
        name={`stocks.${index}.drugId`}
        onChange={(e) => postData(e.target.value)}
        options={data
          .sort((a, b) => a.name.localeCompare(b.name))
          .map((item) => ({
            value: item.id,
            label: item.name,
          }))}
      />
    </>
  );
};
