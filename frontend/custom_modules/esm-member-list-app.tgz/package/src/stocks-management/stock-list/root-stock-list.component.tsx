import {
  Button,
  Column,
  Grid,
  Layer,
  Loading,
  Modal,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
} from '@carbon/react';
import { Tuning } from '@carbon/react/icons';
import { Form, Formik } from 'formik';
import React, { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import * as Yup from 'yup';
import FormikInput from '../../formik/FormikInput';
import FormikSelect from '../../formik/FormikSelect';
import MemberListHeader from '../../header/member-list-header.component';
import { useFetchData } from '../../hooks/useFetchData';
import useModal from '../../hooks/useModal';
import { usePostData } from '../../hooks/usePostData';
import { stockManagement } from '../../resources/api.resource';
import styles from './stockList-styles.scss';

const StockList = () => {
  const { t } = useTranslation();
  const [filterValue, setFilterValue] = useState(null);
  const [selectedItem, setSelectedItem] = useState(null);
  const { postData, loading, data } = usePostData({ fn: stockManagement.stockList });
  const { data: stockProductListData, loading: stockProductListLoading } = useFetchData(
    stockManagement.stockProductList,
  );

  const { isOpen, openModal, closeModal } = useModal();

  const handleSelection = (data) => {
    setSelectedItem(data);
    openModal();
  };
  const handleClose = () => {
    setSelectedItem(null);
    closeModal();
  };

  const validationSchema = Yup.object().shape({
    startDate: Yup.string().optional(),
    endDate: Yup.string().optional(),
    invoice: Yup.string().optional(),
    drugId: Yup.string().optional(),
  });

  useEffect(() => {
    postData({ startDate: '', endDate: '', invoice: '', drugId: 0 });
  }, []);

  if (loading || stockProductListLoading) return <Loading active={loading} />;

  return (
    <div>
      <MemberListHeader
        title={t('stock_list', 'Stock List')}
        secondTitle={t('stock_management', 'Stock Management')}
        type="stock"
      />
      <Layer className={styles['stock-in-form']}>
        <Formik
          initialValues={{ startDate: '', endDate: '', invoice: '', drugId: '' }}
          validationSchema={validationSchema}
          onSubmit={(values) => {
            const apiPayload = { ...values, drugId: values.drugId || 0 };
            setFilterValue(apiPayload);
            postData(apiPayload);
          }}
        >
          {() => (
            <Form>
              <fieldset disabled={loading}>
                <Grid fullWidth className="grid-gap">
                  <Column sm={4} md={2} lg={4}>
                    <FormikInput
                      id="startDate"
                      name="startDate"
                      type="date"
                      label={t('from_stock_in_date', 'FROM: Stock In Date')}
                    />
                  </Column>
                  <Column sm={4} md={2} lg={4}>
                    <FormikInput
                      id="endDate"
                      name="endDate"
                      type="date"
                      label={t('to_stock_in_date', 'TO: Stock In Date')}
                    />
                  </Column>
                  <Column sm={4} md={2} lg={4}>
                    <FormikInput id="invoice" name="invoice" label={t('invoice', 'Invoice')} />
                  </Column>
                  <Column sm={4} md={2} lg={4}>
                    <FormikSelect
                      options={
                        (stockProductListData as any)
                          ?.sort((a, b) => a.name.localeCompare(b.name))
                          .map((item) => ({ value: item.id, label: item.name })) || []
                      }
                      id="drugId"
                      name="drugId"
                      label={t('drug_id', 'Drug')}
                    />
                  </Column>
                </Grid>
                <div className={styles['action-buttons']}>
                  <Button size="lg" type="submit">
                    {t('submit', 'Submit')}
                  </Button>
                </div>
              </fieldset>
            </Form>
          )}
        </Formik>
        <div className={styles['table-container']}>
          <TableContainer style={{ overflowX: 'none' }}>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>#</TableCell>
                  <TableCell>{t('name', 'Name')}</TableCell>
                  <TableCell>{t('quantity', 'Quantity')}</TableCell>
                  <TableCell>{t('stock_in_date', 'Stock In Date')}</TableCell>
                  <TableCell>{t('invoice', 'Invoice')}</TableCell>
                  <TableCell>{t('provider', 'Provider')}</TableCell>
                  <TableCell>{t('action', 'Action')}</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {data?.map((item, index) => (
                  <TableRow key={index}>
                    <TableCell>{index + 1}</TableCell>
                    <TableCell>{item.name}</TableCell>
                    <TableCell>{item.quantity}</TableCell>
                    <TableCell>{item.stock_in_date}</TableCell>
                    <TableCell>{item.invoice}</TableCell>
                    <TableCell>{item.username}</TableCell>
                    <TableCell>
                      <Button
                        style={{ display: 'flex', justifyContent: 'center' }}
                        size="sm"
                        onClick={() => handleSelection(item)}
                        hasIconOnly
                      >
                        <Tuning />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </div>
      </Layer>
      {isOpen && (
        <AdjustmentModal
          isOpen={isOpen}
          closeModal={handleClose}
          selectedItem={selectedItem}
          reFetchFn={() => postData(filterValue ?? { startDate: '', endDate: '', invoice: '', drugId: 0 })}
        />
      )}
    </div>
  );
};

const AdjustmentModal = ({ isOpen, closeModal, selectedItem, reFetchFn }) => {
  const { postData, loading } = usePostData({ fn: stockManagement.stockAdjust });
  return (
    <Modal open={isOpen} onRequestClose={closeModal} modalHeading={selectedItem?.name} size="xs" passiveModal>
      <div style={{ marginLeft: '12px' }}>
        {loading && <Loading active />}
        <Formik
          initialValues={{
            adjustAmount: '',
            adjustDate: '',
            adjustReason: '',
            sid: selectedItem?.sid,
          }}
          validationSchema={Yup.object().shape({
            adjustAmount: Yup.string().required('Adjustment amount is required'), // Make sure it's not empty
            adjustDate: Yup.string().required('Adjustment date is required'), // Make sure the date is not empty
            adjustReason: Yup.string().required('Adjustment reason is required'), // Make sure it's not empty
          })}
          onSubmit={(value) => {
            postData([value], () => {
              if (reFetchFn) {
                reFetchFn();
                closeModal();
              }
            });
          }}
        >
          <Form>
            <FormikInput name="adjustDate" label="Date" type="date" />
            <FormikInput name="adjustAmount" label="Amount" type="number" />
            <FormikInput name="adjustReason" label="Reason" />
            <div style={{ display: 'flex', justifyContent: 'end', marginTop: '16px' }}>
              <Button type="submit" size="sm">
                Submit
              </Button>
            </div>
          </Form>
        </Formik>
      </div>
    </Modal>
  );
};

export default StockList;
