import { Calendar } from '@carbon/react/icons';
export const dashboardMetaMemberProfile = {
  name: 'member-profile',
  slot: 'member-profile-dashboard-slot',
  title: 'Member Profile',
};
