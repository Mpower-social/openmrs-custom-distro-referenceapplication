import React, { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Button, DatePickerInput, Dropdown } from '@carbon/react';
import { Location } from '@carbon/react/icons';
import { useSession, useLayoutType, ConfigurableLink } from '@openmrs/esm-framework';
// import { useAppointmentServices } from '../hooks/useAppointmentService';
import SearchMemberIllustration from './search-member-illustration.component';
import styles from './member-profile-header.scss';

interface AppointmentHeaderProps {
  title: string;
  secondTitle: string;
  appointmentServiceType?: string;
  onChange?: (evt) => void;
}

const MemberProfileHeader: React.FC<AppointmentHeaderProps> = ({ title, secondTitle, onChange }) => {
  const { t } = useTranslation();
  const session = useSession();
  const location = session?.sessionLocation?.display;
  const [memberID, setMemberID] = useState('');

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    setMemberID(params.get('id') ? params.get('id') : '');

    //memberProfileInfo();
  }, []);
  const editURL='${openmrsSpaBase}/patient/'+memberID.replace("$%7B","")+'/edit'
  return (
    <div className={styles.header} data-testid="search-member-header">
      <div className={styles['left-justified-items']}>
        <SearchMemberIllustration />
        <div className={styles['page-labels']}>
          <p className={styles['page-name']}>{title}</p>
        </div>
      </div>
      <div style={{ marginTop: 'auto', marginBottom: 'auto', marginRight: '10px' }}>
        <ConfigurableLink to={editURL} >
          <Button size="md">{t('edit','Edit')}</Button>
        </ConfigurableLink>
      </div>
    </div>
  );
};

export default MemberProfileHeader;
