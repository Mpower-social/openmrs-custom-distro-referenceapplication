import React from 'react';

const SearchMemberIllustration: React.FC = () => {
  return (
    <svg width="92" height="94" viewBox="0 0 92 94" xmlns="http://www.w3.org/2000/svg">
      <title>Member queue illustration</title>
      <g fill="none" fillRule="evenodd">
        <path fill="#FFF" d="M0 0h92v94H0z" />
        <path
          d="M32 75V60.312c0-7.402 5.24-13.59 12.3-15.216-3.2-1.39-5.42-4.523-5.42-8.166 0-4.935 4.08-8.93 9.12-8.93 5.04 0 9.12 3.995 9.12 8.93 0 3.642-2.22 6.776-5.42 8.166C58.76 46.741 64 52.91 64 60.313V75"
          fill="#ed4246"
        />
      </g>
    </svg>
  );
};

export default SearchMemberIllustration;
