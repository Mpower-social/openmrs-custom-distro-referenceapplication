import { showSnackbar } from '@openmrs/esm-framework';
import { useCallback, useState } from 'react';

interface PostOptions<T = any> {
  fn: (data?: T) => Promise<Response>;
  onSuccess?: (data?: any) => void;
  onError?: (error: Error) => void;
}

export function usePostData<T>({ fn, onSuccess, onError }: PostOptions<T>) {
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState(null);
  const [error, setError] = useState<Error | null>(null);

  const postData = useCallback(
    async (payload?: T, onSuccessCallback?: (data?: any) => void) => {
      setLoading(true);
      setError(null);

      try {
        const response = await fn(payload);
        if (!response.ok) {
          throw new Error(`Failed to post data: ${response.statusText}`);
        }

        const responseData = await response.json();
        onSuccess?.(responseData);
        onSuccessCallback?.(responseData);
        setData(responseData);
        return responseData;
      } catch (err: any) {
        setError(err);
        showSnackbar({
          title: err.name,
          subtitle: err.message,
          kind: 'error',
        });
        onError?.(err);
        throw err;
      } finally {
        setLoading(false);
      }
    },
    [fn, onSuccess, onError],
  );

  return { postData, loading, error, data };
}
