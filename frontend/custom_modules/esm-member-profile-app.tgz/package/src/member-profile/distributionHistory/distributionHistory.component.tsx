import { Layer, Table, TableBody, TableCell, TableContainer, TableHead, TableRow } from '@carbon/react';
import dayjs from 'dayjs';
import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';

interface DistributionHistoryData {
  name: string;
  day: number;
  quantity: number;
  distributeDate: string;
  pid: number;
  drugId: any;
  hrmId: string;
  uuid: any;
  divisionId: number;
  districtId: number;
  upazilaId: number;
  paurasavaId: number;
  unionId: number;
  wardId: number;
  facilityCode: string;
  serverVersion: any;
  patient: number;
  patientUuid: string;
}

interface DistributionHistoryProps {
  data: DistributionHistoryData[];
}

const DistributionHistory: React.FC<DistributionHistoryProps> = ({ data = [] }) => {
  const { t } = useTranslation();
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');

  const sortedData = [...data].sort((a, b) => {
    return sortOrder === 'asc'
      ? dayjs(a.distributeDate).valueOf() - dayjs(b.distributeDate).valueOf()
      : dayjs(b.distributeDate).valueOf() - dayjs(a.distributeDate).valueOf();
  });

  const handleSortByDate = () => {
    setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
  };

  return (
    <Layer>
      <TableContainer>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>{t('sn', 'SN')}</TableCell>
              <TableCell>{t('drugName', 'Drug Name')}</TableCell>
              <TableCell>{t('day', 'Day')}</TableCell>
              <TableCell>{t('quantity', 'Quantity')}</TableCell>
              <TableCell onClick={handleSortByDate} style={{ cursor: 'pointer' }}>
                {t('givenDate', 'Given Date')} {sortOrder === 'asc' ? '▲' : '▼'}
              </TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {sortedData.length > 0 ? (
              sortedData.map((item, index) => (
                <TableRow key={index}>
                  <TableCell>{index + 1}</TableCell>
                  <TableCell>{item.name}</TableCell>
                  <TableCell>{item.day}</TableCell>
                  <TableCell>{item.quantity}</TableCell>
                  <TableCell>{dayjs(item.distributeDate).format('YYYY/MM/DD')}</TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={5} style={{ textAlign: 'center' }}>
                  No data available
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </TableContainer>
    </Layer>
  );
};

export default DistributionHistory;
