interface MemberObjRearrangeElement {
  label: string;
  key: string;
  fn?: (el: string) => string; // Optional fn property
}
interface MemberObjRearrange {
  [group: string]: MemberObjRearrangeElement[];
}

const genderFullForm = (value: string) => {
  const genderMap = {
    F: 'Female',
    M: 'Male',
    O: 'Other',
  };
  return genderMap[value] || 'Unknown';
};

export const memberObjRearrange: MemberObjRearrange = {
  firstGroup: [
    { label: 'First name', key: 'givenName' },
    { label: 'Middle name', key: 'middleName' },
    { label: 'Last name', key: 'familyName' },
    { label: 'Full Name (Bangla)', key: 'fullNameBangla' },
    { label: 'Gender', key: 'gender', fn: (el) => genderFullForm(el) },
    { label: 'Phone', key: 'phone' },
    { label: 'Mother Name', key: 'motherName' },
    { label: 'Mother Name (Bangla)', key: 'motherNameBangla' },
    { label: 'Father Name', key: 'fatherName' },
    { label: 'Father Name (Bangla)', key: 'fatherNameBangla' },
    { label: 'DOB', key: 'birthdate', fn: (el) => el.split('T')[0] },
    { label: 'Blood Group', key: 'bloodGroup' },
    { label: 'Marital Status', key: 'matritalStatus' },
    { label: 'Status', key: 'status' },
  ],
  secondGroup: [
    { label: 'Religion', key: 'relegion' },
    { label: 'Birth Place', key: 'birthPlace' },
    { label: 'NID', key: 'nid' },
    { label: 'BRN', key: 'brn' },
    { label: 'Nationality', key: 'nationality' },
    { label: 'Occupation', key: 'occupation' },
    { label: 'Education Qualification', key: 'eduQualification' },
    { label: 'Spouse Name', key: 'spouseNameEnglish' },
    { label: 'Spouse Name (Bangla)', key: 'spouseNameBangla' },
    { label: 'Disability Type', key: 'disabilityType' },
    { label: 'Ethnicity', key: 'ethnicity' },
    { label: 'Nationality', key: 'nationality' },
  ],
  threeGroup: [
    { label: 'Division', key: 'division' },
    { label: 'District', key: 'district' },
    { label: 'Upazila', key: 'upazila' },
    { label: 'Paurasava', key: 'paurasava' },
    { label: 'Union', key: 'unionName' },
    { label: 'Ward', key: 'ward' },
    { label: 'Address(House no/Road no)', key: 'address' },
  ],
};
