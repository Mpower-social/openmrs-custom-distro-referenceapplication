import { Column, Grid, Loading, Row, Tab, TabList, TabPanel, TabPanels, Tabs } from '@carbon/react';
import { UserAvatarFilled, WarningAlt } from '@carbon/react/icons';
import { showSnackbar } from '@openmrs/esm-framework';
import dayjs from 'dayjs';
import React, { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { usePostData } from '../hooks/usePostData';
import useQueryParams from '../hooks/useQueryParams';

import {
  getConceptByID,
  getInfoFromCustomPerson,
  getMemberProfileInfo,
  getMemberVisits,
  stockManagement,
} from '../resources/api.resource';
import ServiceFormComponent from '../service/form.component';
import ServiceHistoryComponent from '../service/history.component';
import DistributionHistory from './distributionHistory/distributionHistory.component';
import { memberObjRearrange } from './member-obj-rearrange';
import StockDistribution from './stockDistribution/distribution.component';

const useServiceHistory = () => {
  const { id } = useQueryParams();

  const {
    data: historyData,
    postData: historyPostData,
    loading: historyLoading,
  } = usePostData({
    fn: () => getMemberVisits(id),
  });

  const processFormStatus = (data, memberInfo) => {
    const today = dayjs();
    const historyList = [...(data?.results ?? [])]?.reverse();
    const processValue = historyList
      .map((item) => ({
        name: item.form?.display,
        field: item.obs?.map((el) => ({
          label: el?.display.split(':')[0],
          value: el?.display.split(':')[1],
        })),
      }))
      .find((item) => item.name === 'গর্ভাবস্থার তথ্য');

    const getFormValue = () => {
      const replaceSpace = (str) => str?.replace(/\s+/g, '') ?? '';

      const getValue = (title) =>
        replaceSpace(processValue?.field?.find((item) => replaceSpace(item?.label) === replaceSpace(title))?.value);

      const formValue = getValue('গর্ভাবস্থা সম্পর্কিত তথ্য');
      const pncVal = getValue('প্রসবের তারিখ');
      const pregnancyDays = pncVal ? dayjs(today).diff(pncVal, 'day') : '';

      const statusMap = {
        প্রসবপূর্ব: 'ANC',
        প্রসবোত্তর: 'PNC',
      };

      return {
        pregnancyDays,
        status: statusMap[formValue] || memberInfo?.status,
        pregnancyDate: pncVal,
        maritalStatus: memberInfo?.maritalStatus,
        gender: memberInfo?.gender,
      };
    };

    return getFormValue();
  };

  return {
    historyData,
    historyPostData,
    historyLoading,
    processFormStatus,
  };
};

const MemberProfileDataTable: React.FC = () => {
  const [loading, setLoadingSet] = useState(true);
  const { t } = useTranslation();
  const [memberInfo, setMemberInfo] = useState<any>();
  const [memberID, setMemberID] = useState('');
  const { id } = useQueryParams();
  const {
    data: distributionHistoryData,
    loading: distributionHistoryLoading,
    postData,
  } = usePostData({
    fn: stockManagement.patientGivenMedicineList,
  });

  const { historyData, historyPostData, historyLoading, processFormStatus } = useServiceHistory();

  const refetchDistributionList = () => postData(id);
  const memberProfileInfo = async (uuid) => {
    setLoadingSet(true);
    try {
      if (!uuid) return;
      const response = await getMemberProfileInfo(uuid);
      const responseCustomPerson = await getInfoFromCustomPerson(uuid);
      let tempAttributes = response.data.attributes;
      let tempObj = {};
      await Promise.all(
        tempAttributes.map(async (el) => {
          const value = el.value.length !== 36 ? el.value : await getConceptDetails(el.value);
          tempObj[el.attributeType.display] = value;
        }),
      );

      let tempMergedMemberInfo = {
        ...response.data,
        highRisk: responseCustomPerson.data.person.highRisk,
        ...tempObj,
        ...response.data.names[0],
      };
      Object.keys(tempMergedMemberInfo).forEach((key) => {
        if (
          tempMergedMemberInfo[key] === null ||
          tempMergedMemberInfo[key] === undefined ||
          tempMergedMemberInfo[key] === ''
        ) {
          delete tempMergedMemberInfo[key];
        }
      });
      setMemberInfo({
        ...tempMergedMemberInfo,
        formInfo: {
          maritalStatus: tempMergedMemberInfo?.matritalStatus,
          status: responseCustomPerson?.data?.person?.status,
          gender: responseCustomPerson?.data?.person?.gender,
        },
      });
      setLoadingSet(false);
    } catch (error) {
      console.error('Failed to fetch members:', error);
      setLoadingSet(false);
      showSnackbar({
        title: error.name,
        subtitle: error.message,
        kind: 'error',
      });
    }
  };

  const getConceptDetails = async (id) => {
    try {
      const conceptInfo = await getConceptByID(id);
      return conceptInfo.data.display;
    } catch (err) {
      return id;
    }
  };

  useEffect(() => {
    setMemberID(id);
    memberProfileInfo(id);
  }, [id]);

  useEffect(() => {
    refetchDistributionList();
  }, [id]);

  useEffect(() => {
    historyPostData();
  }, [id]);

  return (
    <>
      {loading || distributionHistoryLoading || historyLoading ? (
        <Loading active={loading} />
      ) : (
        <div style={{ borderBottom: '1px solid #E0E0E0', marginBottom: '20px' }}>
          <Grid data-test-id="search-member-header" style={{ padding: '20px' }}>
            <Column sm={3} md={3} lg={3}>
              <UserAvatarFilled style={{ height: '150px', width: '150px' }} />
              {memberInfo?.highRisk && <WarningAlt style={{ height: '30px', width: '30px' }} color="red" />}
            </Column>

            {Object.values(memberObjRearrange).map((item) => {
              const newInfo = { ...memberInfo, ...processFormStatus(historyData, memberInfo?.formInfo) };
              return (
                <Column sm={4} md={4} lg={4}>
                  {item.map((el) => {
                    return (
                      newInfo[el.key] && (
                        <Row style={{ padding: '10px 0' }}>
                          <span style={{ fontWeight: 'bold' }}>{t(el.key, el.label)} : </span>
                          <span>{el.fn ? el.fn(newInfo[el.key]) : newInfo[el.key] ?? ''}</span>
                        </Row>
                      )
                    );
                  })}
                </Column>
              );
            })}
          </Grid>
        </div>
      )}
      <div>
        <Tabs>
          <TabList aria-label="List of tabs" contained>
            <Tab color="black">{t('serviceForm', 'Service Form')}</Tab>
            <Tab>{t('serviceHistory', 'Service History')}</Tab>
            <Tab>{t('medicineDistribution', 'Medicine Distribution')}</Tab>
            <Tab>{t('medicineDistributionHistory', 'Medicine Distribution History')}</Tab>
          </TabList>
          <TabPanels>
            <TabPanel>
              {memberInfo && memberInfo?.formInfo && historyData && (
                <ServiceFormComponent
                  processFormData={{
                    ...processFormStatus(historyData, memberInfo?.formInfo),
                  }}
                  memberID={memberID}
                  memberInfo={memberInfo}
                  refetchFn={refetchDistributionList}
                  historyPostDataRetch={historyPostData}
                />
              )}
            </TabPanel>
            <TabPanel>
              <ServiceHistoryComponent historyData={historyData} />
            </TabPanel>
            <TabPanel>
              <StockDistribution patientId={id} refetchFn={refetchDistributionList} />
            </TabPanel>
            <TabPanel>
              <DistributionHistory data={distributionHistoryData ?? []} />
            </TabPanel>
          </TabPanels>
        </Tabs>
      </div>
    </>
  );
};
export default MemberProfileDataTable;
