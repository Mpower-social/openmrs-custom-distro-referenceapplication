import {
  Button,
  Layer,
  Loading,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
} from '@carbon/react';
import { showSnackbar } from '@openmrs/esm-framework';
import { FieldArray, Form, Formik, useFormikContext } from 'formik';
import React, { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import * as Yup from 'yup';
import FormikInput from '../../formik/FormikInput';
import FormikSelect from '../../formik/FormikSelect';
import { useFetchData } from '../../hooks/useFetchData';
import { usePostData } from '../../hooks/usePostData';
import { stockManagement } from '../../resources/api.resource';
import styles from './stock-distribution-styles.scss';

interface StockDistributionProps {
  patientId: string;
  refetchFn?: () => void;
}

const StockDistribution: React.FC<StockDistributionProps> = ({ patientId, refetchFn }) => {
  const { t } = useTranslation();


  const { data, loading, error, refetch: refetchList } = useFetchData<any[]>(stockManagement.stockProductList);
  const { postData, loading: loadingSubmission } = usePostData({
    fn: stockManagement.saveProductDistribution,
    onSuccess: () => {
      refetchList();
      if (refetchFn) {
        refetchFn();
      }
    },
  });

  // Handle loading and error states
  if (loading) return <p>Loading...</p>;
  if (error) {
    showSnackbar({
      title: error.name,
      subtitle: error.message,
      kind: 'error',
    });
  }

  // Formik validation schema for form data
  const validationSchema = Yup.object().shape({
    stocks: Yup.array().of(
      Yup.object().shape({
        drugId: Yup.string().required('Drug is required'),
        stock: Yup.number().typeError('Stock must be a number').required('Stock is required'),
        quantity: Yup.number()
          .typeError('Quantity must be a number')
          .required('Quantity is required')
          .test('stock-check', 'Not enough stock', function (quantity) {
            return Number(this.parent.stock) >= Number(quantity);
          })
          .test('stock-check', 'Value should more then 0', function (quantity) {
            return Number(quantity) > 0;
          }),
        day: Yup.string().required('Day is required'),
        patientId: Yup.string().required('Patient ID is required'),
      }),
    ),
  });



  return (
    <Layer>
      <Formik
        validationSchema={validationSchema}
        initialValues={{
          stocks: [{ drugId: '', stock: '', quantity: '', day: '', patientId }],
        }}
        onSubmit={async (values, { resetForm }) => {
          postData(values.stocks, () => {
            resetForm();
            showSnackbar({
              title: 'Submitted Successfully',
              kind: 'success',
            });
          });
        }}
      >
        {({ values }) => (
          <Form>
            <fieldset disabled={loadingSubmission}>
              <FieldArray name="stocks">
                {({ remove, push }) => (
                  <div>
                    <TableContainer data-testid="encountersTable">
                      <Table>
                        <TableHead>
                          <TableRow>
                            <TableCell>{t('sn', 'SN')}</TableCell>
                            <TableCell>{t('drugList', 'Drug List')}</TableCell>
                            <TableCell>{t('stock', 'Stock')}</TableCell>
                            <TableCell>{t('day', 'Day')}</TableCell>
                            <TableCell>{t('quantity', 'Quantity')}</TableCell>
                            <TableCell>{t('actions', 'Actions')}</TableCell>
                          </TableRow>
                        </TableHead>
                        <TableBody>
                          {/* Render each stock row dynamically */}
                          {values.stocks.map((_, index, mainArray) => (
                            <TableRow key={index}>
                              <TableCell>{index + 1}</TableCell>
                              <TableCell style={{ maxWidth: '200px' }}>
                                <StockProductList index={index} data={data} />
                              </TableCell>
                              <TableCell>
                                <FormikInput name={`stocks.${index}.stock`} placeholder="Stock" disabled />
                              </TableCell>
                              <TableCell>
                                <FormikInput name={`stocks.${index}.day`} placeholder="Day" />
                              </TableCell>
                              <TableCell>
                                <FormikInput name={`stocks.${index}.quantity`} placeholder="Quantity" />
                              </TableCell>
                              <TableCell>
                                <div style={{ display: 'flex', justifyContent: 'center' }}>
                                  {/* Add a row if it's the last row */}
                                  {(mainArray.length !== index + 1 ||
                                    (mainArray.length > 1 && index === mainArray.length - 1)) && (
                                    <button
                                      type="button"
                                      title="Delete"
                                      className={styles['delete-button']}
                                      onClick={() => remove(index)}
                                    >
                                      <svg
                                        xmlns="http://www.w3.org/2000/svg"
                                        viewBox="0 0 24 24"
                                        width="24"
                                        height="24"
                                      >
                                        <path
                                          fill="none"
                                          stroke="#D32F2F"
                                          strokeWidth="2"
                                          d="M3 6h18M5 6l1 14h12l1-14M10 6V4a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v2M4 6h16"
                                        />
                                      </svg>
                                    </button>
                                  )}
                                  {mainArray.length === index + 1 && (
                                    <button
                                      type="button"
                                      title="Add"
                                      onClick={() => {
                                        const { drugId, stock, quantity, day } = values.stocks[index];
                                        if (values.stocks.filter((el) => el.drugId === drugId).length > 1) {
                                          return showSnackbar({
                                            title: 'Medicine already added',
                                            kind: 'error',
                                          });
                                        }
                                        if (![drugId, stock, quantity, day].every(Boolean)) {
                                          return showSnackbar({
                                            title: 'Fill out empty fields',
                                            kind: 'error',
                                          });
                                        }

                                        if (Number(stock) < Number(quantity)) {
                                          return showSnackbar({
                                            title: 'Not enough stock',
                                            kind: 'error',
                                          });
                                        }

                                        push({
                                          drugId: '',
                                          stock: '',
                                          quantity: '',
                                          day: '',
                                          patientId,
                                        });
                                      }}
                                      className={styles['add-button']}
                                    >
                                      <svg
                                        xmlns="http://www.w3.org/2000/svg"
                                        width={19}
                                        height={19}
                                        viewBox="0 0 100 100"
                                      >
                                        <rect x={40} y={10} width={20} height={80} fill="black" />
                                        <rect x={10} y={40} width={80} height={20} fill="black" />
                                      </svg>
                                    </button>
                                  )}
                                </div>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </TableContainer>
                  </div>
                )}
              </FieldArray>

              <div className={styles['action-buttons']}>
                <Button type="submit">{t('submit', 'Submit')}</Button>
              </div>
            </fieldset>
          </Form>
        )}
      </Formik>
    </Layer>
  );
};

interface StockProductListProps {
  index: number;
  data: any[];
}

const StockProductList: React.FC<StockProductListProps> = ({ index, data }) => {
  const { setFieldValue } = useFormikContext();
  const [stockCount, setStockCount] = useState<number | null>(null);

  // Fetch stock count for the selected drug
  const { postData, loading } = usePostData({
    fn: stockManagement.stockProductItemCount,
    onSuccess: (result) => {
      setStockCount(result.count || 0);
      setFieldValue(`stocks.${index}.stock`, result.count || 0);
    },
    onError: () => {
      setFieldValue(`stocks.${index}.stock`, 0);
    },
  });

  useEffect(() => {
    if (stockCount !== null) {
      setFieldValue(`stocks.${index}.stock`, stockCount);
    }
  }, [stockCount, setFieldValue, index]);

  return (
    <>
      {loading && <Loading active={loading} />}
      <FormikSelect
        name={`stocks.${index}.drugId`}
        onChange={(e) => postData(e.target.value)}
        options={data
          .sort((a, b) => a.name.localeCompare(b.name))
          .map((item) => ({
            value: item.id,
            label: item.name,
          }))}
      />
    </>
  );
};

export default StockDistribution;
