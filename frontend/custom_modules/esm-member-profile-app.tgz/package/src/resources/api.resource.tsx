import { openmrsFetch, restBaseUrl } from '@openmrs/esm-framework';

export function listOfForm() {
  const url = `${restBaseUrl}/form?v=custom:(uuid,name,display,encounterType:(uuid,name,viewPrivilege,editPrivilege),version,published,retired,resources:(uuid,name,dataType,valueReference))`;

  return openmrsFetch(url, {
    method: 'GET',
    signal: new AbortController().signal,
  });
}

export function getMemberProfileInfo(uuid: string) {
  const url = `${restBaseUrl}/person/${uuid}?v=full`;

  return openmrsFetch(url, {
    method: 'GET',
    signal: new AbortController().signal,
  });
}

export function getFormByID(id: any) {
  const url = `${restBaseUrl}/o3/forms/${id}`;

  return openmrsFetch(url, {
    method: 'GET',
  });
}

export function getMemberVisits(id: string) {
  //service history
  //const url = `${restBaseUrl}/visit?patient=${id}&v=custom:(uuid,encounters:(uuid,diagnoses:(uuid,display,rank,diagnosis),form:(uuid,display),encounterDatetime,orders:full,obs:(uuid,concept:(uuid,display,conceptClass:(uuid,display)),display,groupMembers:(uuid,concept:(uuid,display),value:(uuid,display),display),value,obsDatetime),encounterType:(uuid,display,viewPrivilege,editPrivilege),encounterProviders:(uuid,display,encounterRole:(uuid,display),provider:(uuid,person:(uuid,display)))),visitType:(uuid,name,display),startDatetime,stopDatetime,patient,attributes:(attributeType:ref,display,uuid,value)`;
  const url = `${restBaseUrl}/encounter?patient=${id}&v=full`;

  return openmrsFetch(url, {
    method: 'GET',
  });
}

export function getInfoFromCustomPerson(id: string) {
  const url = `${restBaseUrl}/custom-person/` + id;

  return openmrsFetch(url, {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
    },
  });
}

export function getConceptByID(id: string) {
  const url = `${restBaseUrl}/concept/` + id;

  return openmrsFetch(url, {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
    },
  });
}

export function makeReferred(data: { personUuid: string; referedDate: string; refered: boolean }) {
  const url = `${restBaseUrl}/custom-person/make-refered`;

  return openmrsFetch(url, {
    method: 'POST',
    body: data,
    headers: {
      'Content-Type': 'application/json',
    },
  });
}

export function makeHighRisk(data: { personUuid: string; highRisk: boolean }) {
  const url = `${restBaseUrl}/custom-person/make-high-risk`;

  return openmrsFetch(url, {
    method: 'POST',
    body: data,
    headers: {
      'Content-Type': 'application/json',
    },
  });
}
export function stockProductList() {
  const url = `${restBaseUrl}/stock/all-product`;
  return openmrsFetch(url, {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
    },
  });
}
export function stockProductItemCount(id) {
  const url = `${restBaseUrl}/stock/getCurrentStockByItem/${id}`;
  return openmrsFetch(url, {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
    },
  });
}

export const stockManagement = {
  stockProductList: () => {
    const url = `${restBaseUrl}/stock/all-product`;
    return openmrsFetch(url, {
      method: 'GET',
      signal: new AbortController().signal,
      headers: {
        'Content-Type': 'application/json',
      },
    });
  },

  stockProductItemCount: (id) => {
    const url = `${restBaseUrl}/stock/getCurrentStockByItem/${id}`;
    return openmrsFetch(url, {
      method: 'GET',
      signal: new AbortController().signal,
      headers: {
        'Content-Type': 'application/json',
      },
    });
  },
  patientGivenMedicineList: (id) => {
    const url = `${restBaseUrl}/product-distribute/patient/${id}`;
    return openmrsFetch(url, {
      method: 'GET',
      signal: new AbortController().signal,
      headers: {
        'Content-Type': 'application/json',
      },
    });
  },
  saveProductDistribution: (payload) => {
    const url = `${restBaseUrl}/product-distribute/save-update`;
    return openmrsFetch(url, {
      method: 'POST',
      signal: new AbortController().signal,
      body: JSON.stringify(payload),
      headers: {
        'Content-Type': 'application/json',
      },
    });
  },
};
