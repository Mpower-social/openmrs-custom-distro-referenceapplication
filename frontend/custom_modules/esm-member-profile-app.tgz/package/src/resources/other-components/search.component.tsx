import React, { useContext } from 'react';
import { Grid, Row, Column, Search, Button, Pagination } from '@carbon/react';

interface SearchComponentForMemberProps {
  onChange?: (evt) => void;
  onClick?: () => void;
  memberChartUrl?: string;
}

const SearchComponentForMember: React.FC<SearchComponentForMemberProps> = ({ onChange, onClick }) => {
  return (
    <Grid data-test-id="search-member-header" style={{ padding: '20px' }}>
      <Column sm={4} md={4} lg={4} style={{ marginLeft: '-25px' }}>
        <Search onChange={(e) => onChange(e.target.value)} placeholder="Search by Name/NID/BRID/Mobile" />
      </Column>
      <Column sm={4} md={4} lg={2} style={{ paddingLeft: '0', display: 'flex', alignItems: 'center' }}>
        <Button size="md" onClick={() => onClick()}>
          Search
        </Button>
      </Column>
    </Grid>
  );
};

export default SearchComponentForMember;
