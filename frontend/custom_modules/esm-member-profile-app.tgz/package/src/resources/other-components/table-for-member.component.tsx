import { WarningAlt } from '@carbon/icons-react';
import React from 'react';

import { Table, TableBody, TableCell, TableContainer, TableHead, TableRow } from '@carbon/react';
import { ConfigurableLink } from '@openmrs/esm-framework';

interface Member {
  uuid: string;
  person: {
    display: string;
    gender: string;
  };
  nid: string;
  phone: string;
  attributes: Array<{ attributeType: { display: string }; value: string }>;
}
interface TableComponentForMemberProps {
  onChange?: (evt) => void;
  members?: Array<Member>;
  memberChartUrl?: string;
}

const valueFromAttribute = (attributes: Array<{ attributeType: { display: string }; value: string }>, key: string) => {
  const attribute = attributes.find((attr) => attr.attributeType.display === key);
  return attribute?.value || 'N/A';
};

const TableComponentForMember: React.FC<TableComponentForMemberProps> = ({ members, memberChartUrl }) => {
  return (
    <div data-testid="list-member-header">
      <TableContainer data-testid="encountersTable">
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>SI</TableCell>
              <TableCell>Member name</TableCell>
              <TableCell>Member Id</TableCell>
              <TableCell>Relation with household head</TableCell>
              <TableCell>Mother name</TableCell>
              <TableCell>Mobile number</TableCell>
              <TableCell>DOB</TableCell>
              <TableCell>Gender</TableCell>
              <TableCell>Ward</TableCell>
              <TableCell>Block</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {members.map((member, index) => (
              <TableRow key={member.uuid}>
                <TableCell>{index + 1}</TableCell>
                <TableCell>
                  <ConfigurableLink to={memberChartUrl} templateParams={{ patientUuid: member.uuid }}>
                    <span style={{ display: 'flex', alignItems: 'center' }}>
                      {index % 2 === 0 && (
                        <WarningAlt
                          color="red"
                          style={{ fontSize: '30px', width: '30px', height: '20px', marginRight: '8px' }}
                        />
                      )}
                      <span>{member.person.display}</span>
                    </span>
                  </ConfigurableLink>
                </TableCell>

                <TableCell>{valueFromAttribute(member.attributes, 'NID')}</TableCell>
                <TableCell>{}</TableCell>
                <TableCell>{}</TableCell>

                <TableCell>{valueFromAttribute(member.attributes, 'Telephone Number')}</TableCell>
                <TableCell>{}</TableCell>
                <TableCell>{}</TableCell>
                <TableCell>{}</TableCell>
                <TableCell>{}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
      {/* <Pagination
        page={currentPage}
        pageSize={pageSize}
        pageSizes={[10, 20, 30, 40, 50]}
        totalItems={members.length}
        onChange={({ page, pageSize }) => {
          setCurrentPage(page);
          setPageSize(pageSize);
        }}
      /> */}
    </div>
  );
};

export default TableComponentForMember;
