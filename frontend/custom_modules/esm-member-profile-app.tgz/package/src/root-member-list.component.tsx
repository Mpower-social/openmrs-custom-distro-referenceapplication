/**
 * From here, the application is pretty typical React, but with lots of
 * support from `@openmrs/esm-framework`. Check out `Greeter` to see
 * usage of the configuration system, and check out `MemberGetter` to
 * see data fetching using the OpenMRS FHIR API.
 *
 * Check out the Config docs:
 *   https://openmrs.github.io/openmrs-esm-core/#/main/config
 */
import MemberProfileHeader from './header/member-profile-header.component';

import React from 'react';
import { useTranslation } from 'react-i18next';
import MemberProfileDataTable from './member-profile/member-profile.component';
const Root: React.FC = () => {
  const { t } = useTranslation();

  return (
    <>
      <MemberProfileHeader title={t('profile', 'Profile')} secondTitle="Member Profile" />
      <br />
      <MemberProfileDataTable />
    </>
  );
};

export default Root;
