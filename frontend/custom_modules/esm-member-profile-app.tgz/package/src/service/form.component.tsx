import { Button, Modal } from '@carbon/react';
import { ExtensionSlot } from '@openmrs/esm-framework';
import dayjs from 'dayjs';
import duration from 'dayjs/plugin/duration';
import relativeTime from 'dayjs/plugin/relativeTime';
import React, { useCallback, useEffect, useMemo, useState } from 'react';

import useFormSchema from '../hooks/useFormSchema';
import { usePostData } from '../hooks/usePostData';
import useQueryParams from '../hooks/useQueryParams';
import StockDistribution from '../member-profile/stockDistribution/distribution.component';
import { getFormByID, listOfForm } from '../resources/api.resource';
import { getMemberVisits, makeReferred, makeHighRisk } from '../resources/api.resource';

dayjs.extend(duration);
dayjs.extend(relativeTime);

const SERVICE_FORM_LIST = {
  infant: ['শিশু (০ থেকে ২ মাস) স্বাস্থ্য সেবা'],
  //child: ['শিশু (২ মাস থেকে ৫ বছর) স্বাস্থ্য সেবা'],
  child: ['6bd3866b-85a1-464f-abd1-bcebac16cdc4', 'Child Services Module'],
  female: ['গর্ভাবস্থার তথ্য'],
  pnc: ['পরিবার পরিকল্পনা সেবা', 'প্রসব পরবর্তী সেবা'],
  anc: ['প্রসব পূর্ব সেবা'],
  male: ['পরিবার পরিকল্পনা সেবা'],
  general: ['সাধারন রোগীর সেবা'],
};

const ServiceFormComponent = ({ memberID, memberInfo, refetchFn, historyPostDataRetch, processFormData }) => {
  const { id } = useQueryParams();
  const [forms, setForms] = useState([]);
  const [distribution, setDistribution] = useState(false);
  const [selectedForm, setSelectedForm] = useState(null);
  const [isOpen, setIsOpen] = useState(false);
  const { schema, error, isLoading } = useFormSchema(selectedForm?.uuid);

  const calculateAge = useCallback((birthDate) => {
    const birth = dayjs(birthDate);
    const today = dayjs();
    return dayjs.duration(today.diff(birth));
  }, []);

  const determineFemaleForms = useMemo(() => {
    const { status, maritalStatus, gender, pregnancyDays } = processFormData;
    if (maritalStatus?.toLowerCase() === 'married' && gender === 'F') {
      if (!status) return SERVICE_FORM_LIST.female;
      if (status.toLowerCase() === 'pnc' && pregnancyDays <= 43) return SERVICE_FORM_LIST.pnc;
      if (status.toLowerCase() === 'anc') return SERVICE_FORM_LIST.anc;
    }
    return [];
  }, [processFormData]);

  const filterFormsByAgeAndGender = useCallback(
    (forms, age) => {
      if (age.years() === 0 && age.months() <= 2)
        return forms.filter(({ name }) => SERVICE_FORM_LIST.infant.includes(name.trim()));
      if (age.years() <= 5) return forms.filter(({ name }) => SERVICE_FORM_LIST.child.includes(name.trim()));
      if (memberInfo.gender === 'F')
        return forms.filter(({ name }) =>
          [...determineFemaleForms, ...SERVICE_FORM_LIST.general].includes(name.trim()),
        );
      if (memberInfo.gender === 'M') {
        return forms.filter(({ name }) =>
          (memberInfo.formInfo?.maritalStatus?.toLowerCase() === 'married'
            ? [...SERVICE_FORM_LIST.male, ...SERVICE_FORM_LIST.general]
            : SERVICE_FORM_LIST.general
          ).includes(name.trim()),
        );
      }
      return forms;
    },
    [memberInfo, determineFemaleForms],
  );

  const { postData } = usePostData(
    useMemo(
      () => ({
        fn: listOfForm,
        onSuccess: (response) => {
          const results = response.results ?? [];
          if (!results.length) return setForms([]);
          setForms(filterFormsByAgeAndGender(results, calculateAge(memberInfo.birthdate)));
        },
        onError: () => setForms([]),
      }),
      [memberInfo, filterFormsByAgeAndGender, calculateAge],
    ),
  );

  const loadFormData = useCallback(async (formId) => {
    setIsOpen(true);
    try {
      const response = await getFormByID(formId);
      setSelectedForm(response.data);
    } catch (error) {
      console.error('Failed to load form data:', error);
    }
  }, []);

  const serviceHistory = async () => {
    try {
      const response = await getMemberVisits(id);
      const allItems = response.data.results?.reverse();
      referredRiskHanlder(allItems[0]);
    } catch (error) {
      console.error('Failed to fetch members:', error);
    }
  };

  const referredRiskHanlder = (lastService) => {
    const referred = lastService.obs.find(
      (el) => el.display.replace(/\s+/g, '') == 'রেফার করা হয়েছে: হ্যাঁ'.replace(/\s+/g, ''),
    );
    makeReferred({
      personUuid: id,
      refered: referred ? true : false,
      referedDate: referred ? new Date().toISOString() : null,
    });

    const riskyValue = ['প্রস্রাবে এলবুমিন উপস্থিতি:  হ্যাঁ', 'গর্ভকালীন বিপদচিহ্ন আছে: হ্যাঁ'].map((el) =>
      el.replace(/\s+/g, ''),
    );
    const risky = lastService.obs.find((el) => riskyValue.includes(el.display.replace(/\s+/g, '')));
    makeHighRisk({ personUuid: id, highRisk: risky ? true : false });
  };

  const closeDialogHandler = useCallback((type: string) => {
    if (type === 'close') {
      setSelectedForm(null);
      setDistribution(false);
      setIsOpen(false);
    } else {
      historyPostDataRetch();
      setDistribution(true);
      serviceHistory();
    }
  }, []);

  useEffect(() => {
    if (memberInfo) postData();
  }, [memberInfo]);

  useEffect(() => {
    if (!isOpen) {
      setSelectedForm(null);
      setDistribution(false);
    }
  }, [isOpen]);

  return (
    <div>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '5px' }}>
        {forms.map(({ uuid, name }) => (
          <Button key={uuid} kind="tertiary" size="md" onClick={() => loadFormData(uuid)}>
            {name}
          </Button>
        ))}
      </div>
      <Modal passiveModal open={isOpen} onRequestClose={() => setIsOpen(false)} modalHeading={selectedForm?.name}>
        {distribution ? (
          <div>
            <h5>Medicine Distribution</h5>
            <StockDistribution
              patientId={id}
              refetchFn={() => {
                historyPostDataRetch();
                setDistribution(false);
                setIsOpen(false);
                refetchFn?.();
              }}
            />
          </div>
        ) : (
          schema?.uuid &&
          !isLoading &&
          !error && (
            <ExtensionSlot
              name="form-slot"
              state={{ patientUuid: memberID, formUuid: selectedForm?.uuid, closeDialogHandler }}
            />
          )
        )}
      </Modal>
    </div>
  );
};

export default ServiceFormComponent;
