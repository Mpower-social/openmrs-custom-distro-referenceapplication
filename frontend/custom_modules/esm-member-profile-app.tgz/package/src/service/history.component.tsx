import {
  Button,
  Modal,
  Pagination,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
} from '@carbon/react';
import React, { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';

const ServiceHistoryComponent = ({ historyData }) => {
  const { t } = useTranslation();
  const [historyList, setHistoryList] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [totalServices, setTotalServices] = useState([]);
  const [selectedService, setSelectedService] = useState(null);

  useEffect(() => {
    if (historyData?.results) {
      const allItems = [...historyData.results].reverse();
      setTotalServices(allItems);
      updatePageData(allItems, currentPage, pageSize);
    }
  }, [historyData]);

  useEffect(() => {
    updatePageData(totalServices, currentPage, pageSize);
  }, [currentPage, pageSize]);

  const updatePageData = (items, page, size) => {
    const startIdx = (page - 1) * size;
    setHistoryList(items.slice(startIdx, startIdx + size));
  };

  const reformateData = () => {
    const tempData = selectedService?.obs || [];

    const grouped = tempData.reduce(
      (acc, el) => {
        const [key, value] = el.display.split(':').map((s) => s.trim());
        if (!acc[key]) acc[key] = [];
        acc[key].push(value);
        return acc;
      },
      {} as Record<string, string[]>,
    );

    return (
      <>
        {Object.entries(grouped).map(([title]) => (
          <div key={title} style={{ fontSize: '16px' }}>
            <strong>{title}: </strong>
            <>{grouped[title].join(', ')}</>
          </div>
        ))}
      </>
    );
  };

  return (
    <div>
      {historyList.length > 0 && (
        <>
          <TableContainer data-testid="encountersTable">
            <Table>
              <TableHead>
                <TableRow>
                  {['SI', 'Service name', 'Provider', 'Role', 'Date', 'Action'].map((header) => (
                    <TableCell key={header}>{t(header, header)}</TableCell>
                  ))}
                </TableRow>
              </TableHead>
              <TableBody>
                {historyList.map((el, index) => (
                  <TableRow key={el?.uuid}>
                    <TableCell>{pageSize * (currentPage - 1) + index + 1}</TableCell>
                    <TableCell>{el.form?.display}</TableCell>
                    <TableCell>
                      {el?.encounterProviders[0]?.provider.display.split('-')[0]?.trim()?.toUpperCase() || 'Unknown'}
                    </TableCell>
                    <TableCell>
                      {el?.encounterProviders[0]?.provider.display.split('-')[1]?.trim() || 'Unknown'}
                    </TableCell>
                    <TableCell>{el.encounterDatetime?.split('T')[0]}</TableCell>
                    <TableCell>
                      <Button size="sm" kind="tertiary" onClick={() => setSelectedService(el)}>
                        {t('view', 'VIEW')}
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
          <Pagination
            page={currentPage}
            pageSize={pageSize}
            pageSizes={[10, 20, 30, 40, 50]}
            totalItems={totalServices.length || 1}
            onChange={({ page, pageSize }) => {
              setCurrentPage(page);
              setPageSize(pageSize);
            }}
          />
        </>
      )}

      {selectedService && (
        <Modal
          passiveModal
          open={!!selectedService?.uuid}
          onRequestClose={() => setSelectedService(null)}
          primaryButtonText="Close"
          onRequestSubmit={() => setSelectedService(null)}
        >
          <div>
            <h3 style={{ fontWeight: 'bold' }}>{selectedService?.form?.display}</h3>
            <br />
            {reformateData()}
          </div>
        </Modal>
      )}
    </div>
  );
};

export default ServiceHistoryComponent;
